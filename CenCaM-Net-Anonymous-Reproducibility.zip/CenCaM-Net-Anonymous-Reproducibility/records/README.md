# Reference Records

This directory contains immutable, manuscript-aligned records for schema checks, aggregation checks, and AI-guided workflow verification.

These files are not raw outputs from an execution of this archive. Every row or event is marked with `record_origin=manuscript_aligned_reference`. Fresh runs write only to `outputs/` and use `record_origin=executed_run`.

Rebuild the records with:

```bash
python scripts/build_reference_records.py
```

The generator refuses to write outside `records/` and writes a record manifest containing SHA-256 digests.
