from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd
import yaml

from cencam.config import load_config
from cencam.data.prepare import read_canonical_events, stable_uint64
from cencam.data.streaming import MaturityWindows, derive_maturity
from cencam.evaluation import scale_event_delays
from cencam.metrics import binary_metrics


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate frozen predictions under delay shifts")
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--matrix", type=Path, required=True)
    parser.add_argument("--events", type=Path, required=True)
    parser.add_argument("--predictions", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()
    config = load_config(arguments.config)
    events = read_canonical_events(arguments.events)
    events["click_id_key"] = events["click_id"].map(stable_uint64)
    predictions = pd.read_parquet(arguments.predictions).rename(columns={"click_id": "click_id_key"})
    joined = events.merge(predictions[["click_id_key", "probability"]], on="click_id_key", how="inner")
    conditions = yaml.safe_load(arguments.matrix.read_text(encoding="utf-8"))["conditions"]
    windows = MaturityWindows(
        purchase_seconds=int(config["data"]["purchase_window_days"] * 86400),
        refund_seconds=int(config["data"]["refund_window_days"] * 86400),
        hazard_intervals=int(config["model"]["hazard_intervals"]),
    )
    observation_time = events["click_time"].max() + pd.Timedelta(
        seconds=windows.purchase_seconds + windows.refund_seconds
    )
    rows = []
    for name, condition in conditions.items():
        shifted = scale_event_delays(
            joined,
            float(condition["purchase_delay_scale"]),
            float(condition["refund_delay_scale"]),
        )
        labeled = derive_maturity(shifted, observation_time, windows)
        mature = labeled["net_mature"].astype(bool)
        metrics = binary_metrics(
            labeled.loc[mature, "net_label"].to_numpy(),
            labeled.loc[mature, "probability"].to_numpy(),
        )
        rows.append({"condition": name, "observations": int(mature.sum()), **metrics})
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(arguments.output, index=False)
    print(pd.DataFrame(rows).to_string(index=False))


if __name__ == "__main__":
    main()
