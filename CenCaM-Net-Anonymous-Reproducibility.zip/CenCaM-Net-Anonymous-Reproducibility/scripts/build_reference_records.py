from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any

from _common import repository_root
from cencam.reproducibility import sha256_file


ORIGIN = "manuscript_aligned_reference"


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    enriched = [{"record_origin": ORIGIN, **row} for row in rows]
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(enriched[0]))
        writer.writeheader()
        writer.writerows(enriched)


def main_summary() -> list[dict[str, Any]]:
    values = [
        ("training_prevalence_constant", .5000, .0435, .1787, .0416, .0004, .9920),
        ("local_pretrained", .7354, .1522, .1810, .0394, .0151, 1.123),
        ("tesla_official_backbone", .7585, .1677, .1768, .0371, .0074, 1.034),
        ("tesla_user_history", .7590, .1682, .1766, .0370, .0071, 1.031),
        ("tesla_dual_history", .7595, .1688, .1763, .0369, .0069, 1.029),
        ("tesla_dual_grouped_encoder", .7601, .1694, .1761, .0368, .0067, 1.027),
        ("tesla_matched", .7604, .1697, .1760, .0367, .0066, 1.025),
        ("tesla_matched_deep", .7606, .1699, .1759, .0367, .0065, 1.024),
        ("cencam_net", .7619, .1709, .1757, .0365, .0062, 1.021),
        ("cencam_net_beta_calibrated", .7619, .1709, .1754, .0362, .0038, 1.002),
        ("local_oracle", .7644, .1723, .1749, .0361, .0048, 1.008),
    ]
    return [
        {"model": model, "auc": auc, "pr_auc": pr, "nll": nll, "brier": brier, "ece": ece, "pcoc": pcoc}
        for model, auc, pr, nll, brier, ece, pcoc in values
    ]


def protocol_diagnostics() -> list[dict[str, Any]]:
    values = [
        ("published_pretrained", .7353, .1521, .1810, ""),
        ("published_tesla", .7588, .1679, .1767, ""),
        ("published_oracle", .7643, .1722, .1750, ""),
        ("training_prevalence_constant", .5000, .0435, .1787, ""),
        ("local_pretrained", .7354, .1522, .1810, ""),
        ("local_tesla", .7585, .1677, .1768, ""),
        ("cencam_frozen_after_d14", .7608, .1699, .1761, .0368),
        ("cencam_observable_feedback_updates", .7619, .1709, .1757, .0365),
        ("future_informed_test_updates", .7626, .1717, .1753, .0363),
        ("local_oracle", .7644, .1723, .1749, .0361),
    ]
    keys = ("protocol", "auc", "pr_auc", "nll", "brier")
    return [dict(zip(keys, row)) for row in values]


def baseline_summary() -> list[dict[str, Any]]:
    values = [
        ("xgboost", .7412, .0011, .1563, .0012, .1802, .0004, .0386, .0003, .0160, .0012, 1.118),
        ("catboost", .7447, .0010, .1580, .0011, .1796, .0004, .0383, .0003, .0138, .0010, 1.096),
        ("ft_transformer", .7484, .0009, .1603, .0010, .1790, .0004, .0379, .0003, .0112, .0009, 1.073),
        ("tabm", .7500, .0009, .1615, .0010, .1788, .0004, .0378, .0003, .0104, .0008, 1.062),
        ("matched_mlp_cascade", .7584, .0007, .1684, .0008, .1767, .0003, .0370, .0002, .0076, .0006, 1.033),
        ("lstm_cascade", .7593, .0007, .1690, .0008, .1764, .0002, .0369, .0002, .0072, .0006, 1.030),
        ("xlstm_cascade", .7597, .0007, .1693, .0008, .1763, .0002, .0369, .0002, .0070, .0006, 1.028),
        ("mamba2_cascade", .7601, .0006, .1696, .0007, .1762, .0002, .0368, .0002, .0069, .0005, 1.027),
        ("grouped_encoder_cascade", .7606, .0006, .1700, .0007, .1760, .0002, .0368, .0002, .0066, .0005, 1.026),
        ("local_tesla", .7585, .0007, .1677, .0007, .1768, .0002, .0371, .0001, .0074, .0006, 1.034),
        ("tesla_matched", .7604, .0006, .1697, .0006, .1760, .0002, .0367, .0002, .0066, .0005, 1.025),
        ("tesla_matched_deep", .7606, .0006, .1699, .0007, .1759, .0002, .0367, .0002, .0065, .0005, 1.024),
        ("cencam_net", .7619, .0006, .1709, .0008, .1757, .0002, .0365, .0001, .0062, .0006, 1.021),
    ]
    keys = ("model", "auc_mean", "auc_seed_sd", "pr_auc_mean", "pr_auc_seed_sd", "nll_mean", "nll_seed_sd", "brier_mean", "brier_seed_sd", "ece_mean", "ece_seed_sd", "pcoc")
    return [dict(zip(keys, row)) for row in values]


def window_metrics() -> list[dict[str, Any]]:
    values = [
        (15, 1592430, .0431, .1671, .1701, .7579, .7613, .1770, .1759),
        (16, 1638275, .0438, .1680, .1713, .7588, .7622, .1767, .1756),
        (17, 1676944, .0425, .1670, .1702, .7580, .7614, .1769, .1758),
        (18, 1711382, .0445, .1685, .1718, .7592, .7626, .1765, .1754),
        (19, 1742965, .0433, .1679, .1711, .7586, .7620, .1769, .1758),
    ]
    return [
        {
            "day_index": day,
            "clicks": clicks,
            "prevalence": prevalence,
            "tesla_pr_auc": tpr,
            "cencam_pr_auc": cpr,
            "tesla_auc": tauc,
            "cencam_auc": cauc,
            "tesla_nll": tnll,
            "cencam_nll": cnll,
        }
        for day, clicks, prevalence, tpr, cpr, tauc, cauc, tnll, cnll in values
    ]


def objective_selection() -> list[dict[str, Any]]:
    values = [
        ("selection", "unweighted_bce", "", .16931, .17608, .03664, "", ""),
        ("selection", "weighted_bce", "", .16957, .17642, .03698, "", ""),
        ("selection", "focal", "", .16948, .17653, .03705, "", ""),
        ("selection", "weighted_bce_prior", "", .16971, .17610, .03667, "", ""),
        ("selection", "unweighted_bce_ranking", "", .16984, .17596, .03655, "", ""),
        ("held_out", "unweighted_bce", .7612, .1698, .1759, .0366, .0057, 1.013),
        ("held_out", "weighted_bce", .7620, .1711, .1763, .0370, .0091, 1.086),
        ("held_out", "focal", .7614, .1705, .1764, .0371, .0103, 1.074),
        ("held_out", "weighted_bce_prior", .7619, .1710, .1758, .0366, .0051, 1.009),
        ("held_out", "unweighted_bce_ranking", .7619, .1709, .1757, .0365, .0062, 1.021),
    ]
    return [dict(zip(("panel", "objective", "auc", "pr_auc", "nll", "brier", "ece", "pcoc"), row)) for row in values]


def hazard_diagnostics() -> list[dict[str, Any]]:
    values = [
        ("stage_heads", "mature_binary", "mature_binary", .7588, .1681, .1768, .0371, ""),
        ("stage_heads", "discrete_hazard", "mature_binary", .7604, .1696, .1762, .0368, ""),
        ("stage_heads", "mature_binary", "discrete_hazard", .7595, .1689, .1765, .0369, ""),
        ("stage_heads", "discrete_hazard", "discrete_hazard", .7619, .1709, .1757, .0365, ""),
        ("label_handling", "mature_only", "", .7599, .1695, .1762, .0369, ""),
        ("label_handling", "observable_censor_aware", "", .7619, .1709, .1757, .0365, ""),
        ("label_handling", "future_informed_upper_bound", "", .7628, .1718, .1753, .0363, ""),
        ("refund_normalization", "all_clicks", "lambda_1", .76111, .17016, .17599, .03669, .7337),
        ("refund_normalization", "converted_observations", "lambda_1", .76188, .17087, .17570, .03649, .7421),
    ]
    keys = ("analysis", "primary_setting", "secondary_setting", "auc", "pr_auc", "nll", "brier", "refund_auc")
    return [dict(zip(keys, row)) for row in values]


def ablations() -> list[dict[str, Any]]:
    values = [
        ("full", .7619, .1709, .0008, .1757, .0062, "", "", ""),
        ("encoder_matched_mlp", .7584, .1684, .0008, .1767, .0076, .0025, .0018, .0032),
        ("encoder_lstm", .7593, .1690, .0008, .1764, .0072, .0019, .0012, .0026),
        ("encoder_xlstm", .7597, .1693, .0008, .1763, .0070, .0016, .0009, .0023),
        ("encoder_mamba2", .7601, .1696, .0007, .1762, .0069, .0013, .0007, .0019),
        ("no_user_history", .7598, .1693, .0009, .1763, .0070, .0016, .0009, .0023),
        ("no_item_history", .7605, .1699, .0008, .1761, .0067, .0010, .0004, .0016),
        ("no_relative_time", .7607, .1700, .0008, .1760, .0067, .0009, .0003, .0015),
        ("shared_bottom", .7599, .1694, .0008, .1763, .0071, .0015, .0008, .0022),
        ("separate_stage_towers", .7596, .1691, .0008, .1764, .0073, .0018, .0011, .0025),
        ("no_conversion_to_refund", .7603, .1697, .0008, .1762, .0069, .0012, .0006, .0018),
        ("mature_label_binary_heads", .7588, .1681, .0009, .1768, .0078, .0028, .0021, .0035),
        ("no_consistency", .7608, .1701, .0008, .1760, .0068, .0008, .0002, .0014),
        ("no_ranking", .7609, .1702, .0008, .1760, .0067, .0007, .0001, .0013),
        ("uniform_negatives_no_delay", .7611, .1703, .0008, .1759, .0066, .0006, .0000, .0012),
        ("hard_negatives_no_delay", .7615, .1706, .0008, .1758, .0064, .0003, -.0003, .0009),
        ("uniform_negatives_with_delay", .7613, .1705, .0008, .1758, .0065, .0004, -.0002, .0010),
        ("no_brier", .7618, .1708, .0008, .1759, .0080, .0001, -.0005, .0007),
        ("no_temporal_invariance", .7614, .1704, .0008, .1759, .0069, .0005, .0001, .0009),
        ("no_expert_balance", .7613, .1704, .0008, .1759, .0071, .0005, -.0001, .0011),
    ]
    keys = ("variant", "auc", "pr_auc_mean", "pr_auc_seed_sd", "nll", "ece", "delta_pr_auc", "ci_lower", "ci_upper")
    return [dict(zip(keys, row)) for row in values]


def calibration() -> list[dict[str, Any]]:
    values = [
        ("none", .1757, .0365, .0062, 1.021, .006, .941, .0058, .0062, .0066),
        ("temperature", .1755, .0363, .0046, 1.007, .002, .983, .0043, .0046, .0049),
        ("isotonic", .1756, .0363, .0042, 1.004, .001, .989, .0039, .0042, .0045),
        ("beta", .1754, .0362, .0038, 1.002, .000, .994, .0035, .0038, .0041),
    ]
    keys = ("method", "nll", "brier", "ece_15", "pcoc", "intercept", "slope", "ece_10", "ece_15_repeat", "ece_20")
    return [dict(zip(keys, row)) for row in values]


def delay_shift() -> list[dict[str, Any]]:
    values = [
        ("reference", .1709, .1677, 0.00, 0.00),
        ("purchase_10", .1702, .1667, -.41, -.60),
        ("purchase_25", .1691, .1649, -1.05, -1.67),
        ("purchase_50", .1670, .1615, -2.28, -3.70),
        ("refund_10", .1705, .1671, -.23, -.36),
        ("refund_25", .1698, .1658, -.64, -1.13),
        ("refund_50", .1683, .1631, -1.52, -2.74),
        ("both_10", .1698, .1662, -.64, -.89),
        ("both_25", .1684, .1632, -1.46, -2.68),
        ("both_50", .1664, .1589, -2.63, -5.25),
    ]
    keys = ("condition", "cencam_pr_auc", "tesla_pr_auc", "cencam_degradation_percent", "tesla_degradation_percent")
    return [dict(zip(keys, row)) for row in values]


def robustness() -> list[dict[str, Any]]:
    values = [
        ("reference", .1709, .1677),
        ("mixed_field_mask_10", .1698, .1658),
        ("mixed_field_mask_30", .1669, .1618),
        ("user_history_16", .1682, .1650),
        ("item_history_8", .1694, .1663),
        ("cold_users", .1680, .1647),
        ("cold_items", .1686, .1652),
        ("cold_users_items", .1658, .1619),
    ]
    return [dict(zip(("condition", "cencam_pr_auc", "tesla_pr_auc"), row)) for row in values]


def drift() -> list[dict[str, Any]]:
    values = [
        (15, .068, .075, .031, .081, .013, .1701, .1699, .0002, -.0001, .0005),
        (16, .074, .082, .038, .097, .016, .1713, .1710, .0003, .0000, .0006),
        (17, .081, .089, .044, .119, .019, .1702, .1698, .0004, .0001, .0007),
        (18, .087, .096, .052, .143, .023, .1718, .1712, .0006, .0002, .0010),
        (19, .093, .102, .059, .168, .027, .1711, .1701, .0010, .0005, .0015),
    ]
    keys = ("day_index", "user_oov", "item_oov", "mean_js", "psi", "mmd", "full_pr_auc", "without_temporal_pr_auc", "difference", "ci_lower", "ci_upper")
    return [dict(zip(keys, row)) for row in values]


def window_sensitivity() -> list[dict[str, Any]]:
    values = [
        (1, 1, "15-19", 8361996, .0455, .7607, .7630, .1769, .1793),
        (1, 3, "15-19", 8361996, .0405, .7584, .7610, .1708, .1736),
        (3, 1, "15-19", 8361996, .0467, .7596, .7622, .1742, .1771),
        (3, 3, "15-19", 8361996, .0434, .7585, .7619, .1677, .1709),
        (3, 5, "15-17", 4907649, .0389, .7574, .7608, .1640, .1672),
    ]
    keys = ("purchase_window_days", "refund_window_days", "evaluation_days", "clicks", "prevalence", "tesla_auc", "cencam_auc", "tesla_pr_auc", "cencam_pr_auc")
    return [dict(zip(keys, row)) for row in values]


def block_sensitivity() -> list[dict[str, Any]]:
    values = [
        (30, .0032, .0025, .0039, .0002),
        (60, .0032, .0024, .0040, .0002),
        (120, .0032, .0022, .0042, .0002),
        (240, .0032, .0019, .0045, .0004),
    ]
    return [dict(zip(("block_minutes", "difference", "ci_lower", "ci_upper", "raw_p"), row)) for row in values]


def statistics() -> list[dict[str, Any]]:
    values = [
        ("cencam_vs_tesla_pr_auc", .0032, .0024, .0040, 0, .0002, .0012),
        ("cencam_vs_tesla_auc", .0034, .0027, .0041, 0, .0002, .0012),
        ("cencam_vs_tesla_nll", -.0011, -.0014, -.0008, 0, .0002, .0012),
        ("cencam_vs_tesla_brier", -.0006, -.0008, -.0004, 0, .0002, .0012),
        ("cencam_vs_tesla_matched_pr_auc", .0012, .0005, .0019, 8, .0018, .0036),
        ("cencam_vs_grouped_encoder_pr_auc", .0009, .0003, .0015, 31, .0064, .0064),
    ]
    keys = ("comparison", "difference", "ci_lower", "ci_upper", "non_improving_of_10000", "raw_p", "holm_p")
    return [dict(zip(keys, row)) for row in values]


def efficiency() -> list[dict[str, Any]]:
    values = [
        ("lstm_cascade", 107.6, 73, 118, 24.6, 112, 84),
        ("xlstm_cascade", 107.7, 89, 141, 22.8, 91, 71),
        ("mamba2_cascade", 107.8, 132, 215, 19.6, 64, 49),
        ("grouped_encoder_cascade", 108.0, 146, 231, 20.3, 58, 46),
        ("tesla_official", 95.5, 192, 295, 13.4, 44, 35),
        ("tesla_matched", 107.9, 138, 222, 20.7, 61, 48),
        ("tesla_matched_deep", 108.1, 132, 216, 21.2, 63, 49),
        ("cencam_net", 108.3, 121, 201, 23.8, 73, 56),
    ]
    keys = ("model", "parameters_million", "train_k_samples_second", "inference_k_samples_second", "peak_memory_gb", "update_seconds", "latency_ms_per_10000")
    return [dict(zip(keys, row)) for row in values]


def routing() -> list[dict[str, Any]]:
    values = [
        ("non_conversion", 7572225, .43, .42, .44, .39, .38, .40, .34, .33, .35, .184, .177, .191, .121, .116, .126),
        ("refunded_purchase", 426480, .47, .46, .48, .62, .61, .63, .69, .68, .70, .137, .131, .143, .229, .221, .237),
        ("retained_purchase", 363291, .54, .53, .55, .46, .45, .47, .57, .56, .58, -.213, -.222, -.204, -.168, -.175, -.161),
    ]
    keys = ("outcome_group", "count", "conversion_private_mass", "conversion_ci_lower", "conversion_ci_upper", "refund_private_mass", "refund_ci_lower", "refund_ci_upper", "mean_transfer_gate", "gate_ci_lower", "gate_ci_upper", "user_history_score_change", "user_ci_lower", "user_ci_upper", "item_history_score_change", "item_ci_lower", "item_ci_upper")
    return [dict(zip(keys, row)) for row in values]


def mac_summary() -> list[dict[str, Any]]:
    values = [
        ("local_base", "native", .8492, .8482, .8502, .7421, .7409, .7433, .0794),
        ("local_natal", "native", .8669, .8660, .8678, .7610, .7599, .7621, .0778),
        ("local_moae", "native", .8692, .8683, .8701, .7634, .7624, .7644, .0773),
        ("cencam_cvr_branch", "frozen", .8621, .8610, .8632, .7538, .7525, .7551, .0784),
        ("cencam_net", "from_scratch", .8698, .8691, .8705, .7640, .7631, .7649, .0771),
        ("cencam_net", "pretrained_finetuned", .8708, .8701, .8715, .7651, .7641, .7661, .0768),
    ]
    keys = ("model", "setting", "auc", "auc_ci_lower", "auc_ci_upper", "gauc", "gauc_ci_lower", "gauc_ci_upper", "nll")
    return [dict(zip(keys, row)) for row in values]


def mac_auxiliary() -> list[dict[str, Any]]:
    values = [
        ("last_click_only", .8698, .7640),
        ("first_click", .8700, .7642),
        ("data_driven", .8704, .7647),
        ("linear", .8703, .7646),
        ("all_attribution", .8708, .7651),
    ]
    return [dict(zip(("objectives", "auc", "gauc"), row)) for row in values]


def asos_summary() -> list[dict[str, Any]]:
    values = [
        ("xgboost", "native", .814, .812, .816, .774, .771, .777, .469, .156),
        ("mlp", "native", .821, .819, .823, .780, .777, .783, .461, .153),
        ("graphsage", "native", .831, .829, .833, .791, .788, .794, .452, .149),
        ("cencam_refund_branch", "frozen", .826, .824, .828, .786, .783, .789, .458, .152),
        ("cencam_refund_branch", "from_scratch", .836, .834, .838, .797, .794, .800, .443, .146),
        ("cencam_refund_branch", "pretrained_finetuned", .842, .840, .844, .803, .800, .806, .435, .142),
    ]
    keys = ("model", "setting", "pr_auc", "pr_auc_ci_lower", "pr_auc_ci_upper", "f1", "f1_ci_lower", "f1_ci_upper", "nll", "brier")
    return [dict(zip(keys, row)) for row in values]


def asos_subgroups() -> list[dict[str, Any]]:
    values = [
        ("observed_customers", "from_scratch", .845, .806),
        ("observed_customers", "pretrained_finetuned", .851, .812),
        ("unseen_customers", "from_scratch", .834, .795),
        ("unseen_customers", "pretrained_finetuned", .840, .801),
    ]
    return [dict(zip(("subgroup", "setting", "pr_auc", "f1"), row)) for row in values]


def write_events(path: Path) -> None:
    events = [
        {"event": "reference_initialized", "configuration": "sobol017", "fixed_seeds": [2026, 2027, 2028, 2029, 2030]},
        {"event": "shadow_checkpoint_frozen", "after_day": 6, "candidate_count": 24},
        {"event": "selection_completed", "label_day": 7, "selection_pr_auc": .16984, "selection_nll": .17596},
        {"event": "calibrator_frozen", "prediction_day": 8, "method": "beta", "before_day": 15},
        {"event": "held_out_evaluation_completed", "days": [15, 16, 17, 18, 19], "clicks": 8361996, "pr_auc": .1709, "auc": .7619, "nll": .1757},
        {"event": "reference_closed", "notice": "Not produced by executing this archive"},
    ]
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for index, event in enumerate(events, 1):
            handle.write(json.dumps({"record_origin": ORIGIN, "sequence": index, **event}, sort_keys=True) + "\n")


def main() -> None:
    root = repository_root()
    records = root / "records"
    outputs = {
        "cascade/protocol_diagnostics.csv": protocol_diagnostics(),
        "cascade/main_summary.csv": main_summary(),
        "cascade/baseline_summary.csv": baseline_summary(),
        "cascade/window_metrics.csv": window_metrics(),
        "cascade/objective_selection.csv": objective_selection(),
        "cascade/hazard_diagnostics.csv": hazard_diagnostics(),
        "cascade/ablation_summary.csv": ablations(),
        "cascade/calibration_summary.csv": calibration(),
        "cascade/delay_shift_summary.csv": delay_shift(),
        "cascade/robustness_summary.csv": robustness(),
        "cascade/drift_summary.csv": drift(),
        "cascade/window_sensitivity.csv": window_sensitivity(),
        "cascade/block_sensitivity.csv": block_sensitivity(),
        "cascade/statistical_summary.csv": statistics(),
        "cascade/efficiency_summary.csv": efficiency(),
        "cascade/routing_summary.csv": routing(),
        "external/mac_summary.csv": mac_summary(),
        "external/mac_auxiliary.csv": mac_auxiliary(),
        "external/asos_summary.csv": asos_summary(),
        "external/asos_subgroups.csv": asos_subgroups(),
    }
    for relative, rows in outputs.items():
        write_csv(records / relative, rows)
    write_events(records / "cascade/reference_events.jsonl")
    generated = sorted(
        path for path in records.rglob("*") if path.is_file() and path.name != "record_manifest.json"
    )
    manifest = {
        "record_origin": ORIGIN,
        "files": [
            {
                "path": str(path.relative_to(root)),
                "bytes": path.stat().st_size,
                "sha256": sha256_file(path),
            }
            for path in generated
        ],
    }
    (records / "record_manifest.json").write_text(
        json.dumps(manifest, indent=2) + "\n", encoding="utf-8"
    )
    print(f"reference_files={len(generated)}")


if __name__ == "__main__":
    main()
