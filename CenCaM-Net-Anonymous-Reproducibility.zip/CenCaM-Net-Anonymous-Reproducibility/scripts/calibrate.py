from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

from cencam.calibration import make_calibrator
from cencam.config import load_config
from cencam.metrics import binary_metrics


def calibrator_state(calibrator: object) -> dict[str, object]:
    values: dict[str, object] = {"class": calibrator.__class__.__name__}
    for name, value in vars(calibrator).items():
        if isinstance(value, (int, float, str, bool)):
            values[name] = value
    return values


def main() -> None:
    parser = argparse.ArgumentParser(description="Fit a prospective probability calibrator")
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--predictions", type=Path, required=True)
    parser.add_argument("--output", type=Path)
    arguments = parser.parse_args()
    config = load_config(arguments.config)
    frame = pd.read_parquet(arguments.predictions)
    if "day_index" in frame and set(frame["day_index"].unique()) != {int(config["calibration"]["fit_day"])}:
        raise ValueError("Calibration input must contain the prespecified calibration day only")
    mature = frame["net_mature"].astype(bool)
    labels = frame.loc[mature, "net_label"].to_numpy()
    probabilities = frame.loc[mature, "probability"].to_numpy()
    calibrator = make_calibrator(config["calibration"]["method"]).fit(probabilities, labels)
    calibrated = calibrator.predict(probabilities)
    report = {
        "fit_day": int(config["calibration"]["fit_day"]),
        "method": config["calibration"]["method"],
        "observations": int(mature.sum()),
        "uncalibrated": binary_metrics(labels, probabilities),
        "calibrated": binary_metrics(labels, calibrated),
        "state": calibrator_state(calibrator),
    }
    output = arguments.output or arguments.predictions.parent / "calibrator.json"
    output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
