from __future__ import annotations

import argparse
import json
from pathlib import Path

from _common import append_jsonl, loader_for_split, repository_root
from cencam.config import load_config, save_resolved_config
from cencam.model import CenCaMNet
from cencam.reproducibility import environment_report, seed_everything, write_json
from cencam.training import fit_model


def main() -> None:
    parser = argparse.ArgumentParser(description="Train one fixed-seed CenCaM-Net run")
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--set", action="append", default=[])
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--train-split", default="train")
    parser.add_argument("--validation-split", default="selection")
    arguments = parser.parse_args()
    root = repository_root()
    config = load_config(arguments.config, arguments.set)
    seed_everything(arguments.seed, bool(config["run"].get("deterministic", True)))
    output = root / config["run"]["output_root"] / f"seed_{arguments.seed}"
    output.mkdir(parents=True, exist_ok=True)
    save_resolved_config(config, output / "config.resolved.yaml")
    write_json(environment_report(), output / "environment.json")
    events = output / "events.jsonl"
    append_jsonl(events, {"event": "run_started", "seed": arguments.seed})
    batch_size = int(config["optimization"]["batch_size"])
    processed = root / config["data"]["processed_root"]
    train_loader = loader_for_split(
        processed, arguments.train_split, batch_size, True, arguments.workers
    )
    validation_loader = loader_for_split(
        processed, arguments.validation_split, batch_size, False, arguments.workers
    )
    model = CenCaMNet(config["model"])
    summary = fit_model(
        model,
        train_loader,
        validation_loader,
        config,
        output,
        event_writer=lambda record: append_jsonl(events, record),
    )
    append_jsonl(events, {"event": "run_completed", "summary": summary})
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
