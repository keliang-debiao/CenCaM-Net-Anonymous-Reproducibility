from __future__ import annotations

import argparse
import shutil
import subprocess
from pathlib import Path

import yaml

from _common import repository_root


def main() -> None:
    parser = argparse.ArgumentParser(description="Register or acquire a public data resource")
    parser.add_argument("--dataset", required=True, choices=["cascade", "mac", "asos"])
    parser.add_argument("--destination", type=Path, default=Path("external"))
    parser.add_argument("--clone", action="store_true", help="Clone Git repositories when supported")
    arguments = parser.parse_args()
    root = repository_root()
    sources = yaml.safe_load((root / "data/sources.yaml").read_text(encoding="utf-8"))["datasets"]
    source = sources[arguments.dataset]
    target = arguments.destination / arguments.dataset
    target.parent.mkdir(parents=True, exist_ok=True)
    print(f"dataset={arguments.dataset}")
    print(f"public_resource={source['repository']}")
    print(f"paper={source['paper']}")
    print(f"target={target}")
    if not arguments.clone:
        print("status=registration_only")
        return
    if arguments.dataset == "asos":
        raise SystemExit("The ASOS project requires download through its public project page")
    if shutil.which("git") is None:
        raise SystemExit("git is unavailable")
    if target.exists():
        raise SystemExit(f"Destination already exists: {target}")
    subprocess.run(
        ["git", "clone", "--depth", "1", "--filter=blob:none", source["repository"], str(target)],
        check=True,
    )
    print("status=acquired")


if __name__ == "__main__":
    main()
