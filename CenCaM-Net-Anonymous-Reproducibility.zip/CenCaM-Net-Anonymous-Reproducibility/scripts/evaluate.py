from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

from _common import loader_for_split, repository_root
from cencam.config import load_config
from cencam.evaluation import metrics_by_window
from cencam.model import CenCaMNet
from cencam.training import evaluate_loader


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate a checkpoint without parameter updates")
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--split", default="test")
    parser.add_argument("--workers", type=int, default=4)
    arguments = parser.parse_args()
    import torch

    root = repository_root()
    config = load_config(arguments.config)
    device = torch.device(
        "cuda" if config["run"].get("device") == "cuda" and torch.cuda.is_available() else "cpu"
    )
    model = CenCaMNet(config["model"])
    checkpoint = torch.load(arguments.checkpoint, map_location="cpu", weights_only=False)
    model.load_state_dict(checkpoint["model_state"])
    model.to(device)
    loader = loader_for_split(
        root / config["data"]["processed_root"],
        arguments.split,
        int(config["optimization"]["batch_size"]),
        False,
        arguments.workers,
    )
    metrics, arrays = evaluate_loader(
        model,
        loader,
        device,
        str(config["run"].get("precision", "bf16")),
        int(config.get("calibration", {}).get("bins", 15)),
    )
    output = arguments.checkpoint.parent
    pd.DataFrame(
        {
            "click_id": arrays["click_id"],
            "day_index": arrays["day_index"],
            "net_label": arrays["label"],
            "net_mature": arrays["mature"],
            "probability": arrays["probability"],
        }
    ).to_parquet(output / f"{arguments.split}_predictions.parquet", index=False)
    metrics_by_window(
        arrays["label"], arrays["probability"], arrays["day_index"], arrays["mature"]
    ).to_csv(output / f"{arguments.split}_metrics_by_window.csv", index=False)
    (output / f"{arguments.split}_metrics.json").write_text(
        json.dumps(metrics, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(metrics, indent=2))


if __name__ == "__main__":
    main()
