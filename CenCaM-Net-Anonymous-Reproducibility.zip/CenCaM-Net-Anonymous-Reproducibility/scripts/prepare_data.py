from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

from _common import repository_root
from cencam.config import load_config
from cencam.data.prepare import assign_day_index, prepare_arrays, read_canonical_events, write_split_shards
from cencam.data.streaming import MaturityWindows, derive_maturity
from cencam.reproducibility import sha256_file


def register_hashes(paths: list[Path], root: Path, manifest: Path) -> None:
    entries = []
    for path in sorted(paths):
        entries.append(
            {
                "path": str(path.resolve().relative_to(root.resolve())),
                "bytes": path.stat().st_size,
                "sha256": sha256_file(path),
            }
        )
    manifest.parent.mkdir(parents=True, exist_ok=True)
    manifest.write_text(json.dumps({"files": entries}, indent=2) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description="Build chronological fixed-shape data shards")
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--input", type=Path, help="Canonical Parquet or CSV event table")
    parser.add_argument("--observation-time", help="UTC outcome-observation boundary")
    parser.add_argument("--shard-rows", type=int, default=250_000)
    parser.add_argument("--register-hashes", action="store_true")
    arguments = parser.parse_args()
    root = repository_root()
    config = load_config(arguments.config)
    raw_root = root / config["data"]["raw_root"]
    if arguments.register_hashes:
        files = [path for path in raw_root.rglob("*") if path.is_file()]
        register_hashes(files, root, root / "manifests/file_hashes.json")
        print(f"registered_files={len(files)}")
        if arguments.input is None:
            return
    if arguments.input is None:
        raise SystemExit("--input is required unless only registering source-file hashes")
    frame = assign_day_index(read_canonical_events(arguments.input))
    if arguments.observation_time:
        observation_time = pd.Timestamp(arguments.observation_time)
        if observation_time.tzinfo is None:
            observation_time = observation_time.tz_localize("UTC")
    else:
        observation_time = frame["click_time"].max() + pd.Timedelta(days=6)
    frame = derive_maturity(
        frame,
        observation_time,
        MaturityWindows(
            purchase_seconds=int(config["data"].get("purchase_window_days", 3) * 86400),
            refund_seconds=int(config["data"].get("refund_window_days", 3) * 86400),
            hazard_intervals=int(config["model"].get("hazard_intervals", 12)),
        ),
    )
    arrays = prepare_arrays(
        frame,
        dense_width=int(config["model"]["dense_input_dim"]),
        user_length=int(config["data"]["user_history_length"]),
        item_length=int(config["data"]["item_history_length"]),
    )
    destination = root / config["data"]["processed_root"]
    paths = write_split_shards(arrays, destination, arguments.shard_rows)
    audit = {
        "input": str(arguments.input),
        "observation_time": observation_time.isoformat(),
        "rows": len(frame),
        "shards": [path.name for path in paths],
        "net_mature": int(frame["net_mature"].sum()),
        "net_positive": int(frame.loc[frame["net_mature"].astype(bool), "net_label"].sum()),
    }
    (destination / "preparation_audit.json").write_text(
        json.dumps(audit, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(audit, indent=2))


if __name__ == "__main__":
    main()
