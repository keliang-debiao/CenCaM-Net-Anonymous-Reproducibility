from __future__ import annotations

import argparse
import itertools
import json
import subprocess
import sys
from pathlib import Path

import yaml


def main() -> None:
    parser = argparse.ArgumentParser(description="Launch fixed seeds and controlled variants")
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--seeds", nargs="+", type=int, default=[2026, 2027, 2028, 2029, 2030])
    parser.add_argument("--matrix", type=Path)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--dry-run", action="store_true")
    arguments = parser.parse_args()
    variants: list[tuple[str, dict[str, object]]] = [("selected", {})]
    if arguments.matrix:
        loaded = yaml.safe_load(arguments.matrix.read_text(encoding="utf-8"))
        mapping = loaded.get("variants", loaded.get("conditions", {}))
        variants = list(mapping.items())
    for (name, overrides), seed in itertools.product(variants, arguments.seeds):
        command = [
            sys.executable,
            "scripts/train.py",
            "--config",
            str(arguments.config),
            "--seed",
            str(seed),
            "--workers",
            str(arguments.workers),
            "--set",
            f"run.name={name}",
            "--set",
            f"run.output_root=outputs/{arguments.config.stem}/{name}",
        ]
        for key, value in overrides.items():
            command.extend(["--set", f"{key}={json.dumps(value)}"])
        print(" ".join(command), flush=True)
        if not arguments.dry_run:
            subprocess.run(command, check=True)


if __name__ == "__main__":
    main()
