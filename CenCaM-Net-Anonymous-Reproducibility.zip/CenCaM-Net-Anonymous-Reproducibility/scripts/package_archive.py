from __future__ import annotations

import argparse
import subprocess
import sys
import zipfile
from pathlib import Path

from _common import repository_root


def excluded(path: Path, root: Path) -> bool:
    parts = set(path.relative_to(root).parts)
    return bool(parts & {"__pycache__", ".git", "outputs", "raw", "processed"}) or path.suffix == ".pyc"


def main() -> None:
    parser = argparse.ArgumentParser(description="Create a deterministic anonymous-review archive")
    parser.add_argument("--output", type=Path)
    arguments = parser.parse_args()
    root = repository_root()
    subprocess.run([sys.executable, "scripts/build_reference_records.py"], cwd=root, check=True)
    subprocess.run(
        [sys.executable, "scripts/verify_repository.py", "--strict", "--write-manifest"],
        cwd=root,
        check=True,
    )
    output = arguments.output or root.parent / f"{root.name}.zip"
    files = sorted(path for path in root.rglob("*") if path.is_file() and not excluded(path, root))
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in files:
            relative = Path(root.name) / path.relative_to(root)
            info = zipfile.ZipInfo(str(relative), date_time=(2026, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(info, path.read_bytes())
    print(f"archive={output}")
    print(f"files={len(files)}")


if __name__ == "__main__":
    main()
