from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np


def repository_root() -> Path:
    return Path(__file__).resolve().parents[1]


def append_jsonl(path: Path, record: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, sort_keys=True) + "\n")


def load_npz_dataset(paths: list[Path]):
    try:
        import torch
    except ImportError as exc:
        raise RuntimeError("The pinned PyTorch dependency is required") from exc

    class ArrayDataset(torch.utils.data.Dataset):
        def __init__(self, path: Path) -> None:
            self.path = path
            self.arrays = np.load(path, mmap_mode="r", allow_pickle=False)
            self.length = int(self.arrays[self.arrays.files[0]].shape[0])

        def __len__(self) -> int:
            return self.length

        def __getitem__(self, index: int) -> dict[str, Any]:
            return {name: torch.as_tensor(self.arrays[name][index]) for name in self.arrays.files}

    datasets = [ArrayDataset(path) for path in paths]
    if not datasets:
        raise FileNotFoundError("No prepared shards matched the requested split")
    return datasets[0] if len(datasets) == 1 else torch.utils.data.ConcatDataset(datasets)


def loader_for_split(
    processed_root: Path,
    split: str,
    batch_size: int,
    shuffle: bool,
    workers: int,
):
    import torch

    paths = sorted(processed_root.glob(f"{split}_*.npz"))
    dataset = load_npz_dataset(paths)
    return torch.utils.data.DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=workers,
        pin_memory=torch.cuda.is_available(),
        persistent_workers=workers > 0,
    )
