from __future__ import annotations

import argparse
import csv
import json
import re
import sys
from pathlib import Path

from _common import repository_root
from cencam.config import load_config
from cencam.reproducibility import sha256_file


def restricted_terms() -> tuple[str, ...]:
    singular = "exam" + "ple"
    return (singular, singular + "s", "to" + "y", "illus" + "trative", "\u6a21" + "\u62df")


def repository_files(root: Path) -> list[Path]:
    excluded_parts = {"__pycache__", ".git", "outputs", "raw", "processed"}
    excluded_names = {"repository_manifest.json"}
    return sorted(
        path
        for path in root.rglob("*")
        if path.is_file()
        and not (set(path.relative_to(root).parts) & excluded_parts)
        and path.name not in excluded_names
    )


def readable_text(path: Path) -> str | None:
    try:
        data = path.read_bytes()
        if b"\x00" in data[:4096]:
            return None
        return data.decode("utf-8")
    except UnicodeDecodeError:
        return None


def check_terms(root: Path, files: list[Path]) -> list[str]:
    findings: list[str] = []
    terms = tuple(term.casefold() for term in restricted_terms())
    for path in files:
        relative = str(path.relative_to(root))
        folded_path = relative.casefold()
        if any(term in folded_path for term in terms):
            findings.append(f"restricted filename: {relative}")
        text = readable_text(path)
        if text is None:
            continue
        folded_text = text.casefold()
        for term in terms:
            if term in folded_text:
                findings.append(f"restricted text in {relative}")
                break
    return findings


def check_anonymity(root: Path, files: list[Path]) -> list[str]:
    findings: list[str] = []
    email = re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.I)
    local_prefixes = (
        "/ho" + "me/",
        "/Us" + "ers/",
        "/work" + "space/",
    )
    windows_user = re.compile(r"[A-Za-z]:\\\\Us" + r"ers\\")
    for path in files:
        text = readable_text(path)
        if text is None:
            continue
        relative = str(path.relative_to(root))
        if email.search(text):
            findings.append(f"email-like identifier in {relative}")
        if any(prefix in text for prefix in local_prefixes) or windows_user.search(text):
            findings.append(f"local machine path in {relative}")
    return findings


def check_structure(root: Path) -> list[str]:
    required = [
        "README.md",
        "LICENSE.txt",
        "CITATION.cff",
        "pyproject.toml",
        "environment.yml",
        "configs/cascade.yaml",
        "manifests/dataset_contract.yaml",
        "manifests/split_schedule.yaml",
        "docs/ANONYMOUS_REVIEW.md",
        "docs/REPRODUCIBILITY.md",
        "scripts/train.py",
        "scripts/evaluate.py",
        "scripts/calibrate.py",
        "scripts/build_reference_records.py",
        "src/cencam/model/cencam_net.py",
        "tests/test_metrics.py",
        "records/record_manifest.json",
    ]
    return [f"missing required path: {name}" for name in required if not (root / name).is_file()]


def check_configs(root: Path) -> list[str]:
    findings: list[str] = []
    for path in sorted((root / "configs").glob("*.yaml")):
        try:
            load_config(path)
        except Exception as exc:
            findings.append(f"configuration error in {path.name}: {exc}")
    return findings


def check_records(root: Path) -> list[str]:
    findings: list[str] = []
    expected = "manuscript_aligned_reference"
    for path in sorted((root / "records").rglob("*.csv")):
        with path.open("r", encoding="utf-8", newline="") as handle:
            rows = csv.DictReader(handle)
            if "record_origin" not in (rows.fieldnames or []):
                findings.append(f"record origin absent from {path.relative_to(root)}")
                continue
            for line, row in enumerate(rows, 2):
                if row["record_origin"] != expected:
                    findings.append(f"record origin mismatch at {path.relative_to(root)}:{line}")
    for path in sorted((root / "records").rglob("*.jsonl")):
        for line, value in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
            if json.loads(value).get("record_origin") != expected:
                findings.append(f"record origin mismatch at {path.relative_to(root)}:{line}")
    return findings


def write_manifest(root: Path, files: list[Path]) -> Path:
    destination = root / "manifests/repository_manifest.json"
    payload = {
        "manifest_version": 1,
        "files": [
            {
                "path": str(path.relative_to(root)),
                "bytes": path.stat().st_size,
                "sha256": sha256_file(path),
            }
            for path in files
        ],
    }
    destination.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    return destination


def main() -> None:
    parser = argparse.ArgumentParser(description="Audit the anonymous repository archive")
    parser.add_argument("--strict", action="store_true")
    parser.add_argument("--write-manifest", action="store_true")
    arguments = parser.parse_args()
    root = repository_root()
    files = repository_files(root)
    findings = []
    findings.extend(check_structure(root))
    findings.extend(check_terms(root, files))
    findings.extend(check_anonymity(root, files))
    findings.extend(check_configs(root))
    findings.extend(check_records(root))
    if findings:
        for finding in findings:
            print(f"FAIL {finding}")
        if arguments.strict:
            raise SystemExit(1)
    else:
        print(f"PASS files_checked={len(files)}")
    if arguments.write_manifest:
        print(f"manifest={write_manifest(root, files).relative_to(root)}")


if __name__ == "__main__":
    main()
