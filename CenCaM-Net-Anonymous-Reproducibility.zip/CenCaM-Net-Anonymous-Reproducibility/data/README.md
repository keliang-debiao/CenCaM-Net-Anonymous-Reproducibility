# Public Data Setup

No source records are redistributed in this archive.

## CASCADE

- Role: primary rolling-origin NetCVR evaluation.
- Public repository: `https://github.com/alimama-tech/NetCVR`
- Paper: `https://arxiv.org/abs/2601.19965`
- Expected scale: 41.0 million clicks, 2.0 million users, 3.1 million items, 25 days.

Place the source files under `data/raw/cascade/`. Preserve original timestamps and identifiers. Do not randomize row order before the chronology audit.

## MAC

- Role: conversion-stage transfer evaluation.
- Public repository: `https://github.com/alimama-tech/PyMAL`
- Paper: `https://arxiv.org/abs/2603.02184`
- Expected scale: 79.2 million clicks, 0.80 million users, 9.6 million distinct target items, 21 days.

Place the source files under `data/raw/mac/` and retain the four attribution labels.

## ASOS GraphReturns

- Role: return-stage compatibility evaluation.
- Public project: `https://osf.io/c793h/`
- Paper: `https://arxiv.org/abs/2302.14096`
- Expected edges: 1.121 million train, 0.279 million validation, 1.498 million test.

Place the source files under `data/raw/asos/` and retain the official chronological partitions.

## Integrity registration

After placing the files, run:

```bash
python scripts/prepare_data.py --config configs/cascade.yaml --register-hashes
python scripts/prepare_data.py --config configs/mac_transfer.yaml --register-hashes
python scripts/prepare_data.py --config configs/asos_transfer.yaml --register-hashes
```

The command records relative paths, byte sizes, and SHA-256 values in `manifests/file_hashes.json`. Raw data remain outside version control.

