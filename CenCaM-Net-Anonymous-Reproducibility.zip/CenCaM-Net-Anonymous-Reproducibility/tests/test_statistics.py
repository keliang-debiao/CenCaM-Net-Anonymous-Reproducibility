import unittest

import numpy as np

from cencam.statistics import holm_adjust, moving_block_indices


class StatisticTests(unittest.TestCase):
    def test_block_indices(self) -> None:
        indices = moving_block_indices(25, 4, np.random.default_rng(2026))
        self.assertEqual(len(indices), 25)
        self.assertTrue(np.all((indices >= 0) & (indices < 25)))

    def test_holm_is_not_smaller(self) -> None:
        raw = [0.01, 0.04, 0.20]
        adjusted = holm_adjust(raw)
        self.assertTrue(all(a >= p for a, p in zip(adjusted, raw)))


if __name__ == "__main__":
    unittest.main()
