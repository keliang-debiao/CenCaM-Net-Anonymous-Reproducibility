import unittest

import numpy as np

from cencam.calibration import BetaCalibrator, TemperatureCalibrator


class CalibrationTests(unittest.TestCase):
    def setUp(self) -> None:
        self.labels = np.array([0, 0, 0, 1, 1, 1], dtype=float)
        self.probabilities = np.array([0.05, 0.12, 0.30, 0.55, 0.75, 0.92])

    def test_temperature_bounds(self) -> None:
        values = TemperatureCalibrator().fit(self.probabilities, self.labels).predict(
            self.probabilities
        )
        self.assertTrue(np.all((values > 0) & (values < 1)))

    def test_beta_bounds(self) -> None:
        values = BetaCalibrator().fit(self.probabilities, self.labels).predict(
            self.probabilities
        )
        self.assertTrue(np.all((values > 0) & (values < 1)))
        self.assertTrue(np.all(np.diff(values) >= 0))


if __name__ == "__main__":
    unittest.main()
