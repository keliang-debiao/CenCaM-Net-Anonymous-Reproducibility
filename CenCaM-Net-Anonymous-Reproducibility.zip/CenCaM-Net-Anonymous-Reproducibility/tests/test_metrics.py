import unittest

import numpy as np

from cencam.metrics import binary_metrics, expected_calibration_error, group_auc


class MetricTests(unittest.TestCase):
    def test_perfect_ranking(self) -> None:
        labels = np.array([0, 0, 1, 1])
        probabilities = np.array([0.01, 0.10, 0.80, 0.95])
        metrics = binary_metrics(labels, probabilities, bins=2)
        self.assertAlmostEqual(metrics["auc"], 1.0)
        self.assertAlmostEqual(metrics["pr_auc"], 1.0)
        self.assertGreater(metrics["pcoc"], 0.0)

    def test_ece_and_group_auc_are_finite(self) -> None:
        labels = np.array([0, 1, 0, 1, 0, 1])
        probabilities = np.array([0.1, 0.8, 0.2, 0.7, 0.3, 0.9])
        groups = np.array([1, 1, 1, 2, 2, 2])
        self.assertTrue(np.isfinite(expected_calibration_error(labels, probabilities)))
        self.assertTrue(np.isfinite(group_auc(labels, probabilities, groups)))


if __name__ == "__main__":
    unittest.main()
