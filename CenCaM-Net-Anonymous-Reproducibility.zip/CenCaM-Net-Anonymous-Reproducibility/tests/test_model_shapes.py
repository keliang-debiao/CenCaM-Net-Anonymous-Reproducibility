import importlib.util
import unittest


@unittest.skipUnless(importlib.util.find_spec("torch") is not None, "PyTorch is not installed")
class ModelShapeTests(unittest.TestCase):
    def test_forward_shapes(self) -> None:
        import torch

        from cencam.model import CenCaMNet

        config = {
            "dense_input_dim": 8,
            "model_dim": 16,
            "encoder_layers": 1,
            "ssm_groups": 4,
            "complex_states_per_group": 2,
            "convolution_width": 2,
            "shared_experts": 2,
            "private_experts_per_stage": 1,
            "expert_hidden_dim": 24,
            "top_k_experts": 2,
            "dropout": 0.0,
            "hazard_intervals": 6,
        }
        model = CenCaMNet(config)
        batch = {
            "current_dense": torch.randn(3, 8),
            "user_history_dense": torch.randn(3, 5, 8),
            "item_history_dense": torch.randn(3, 4, 8),
            "user_history_mask": torch.tensor([[0, 0, 1, 1, 1]] * 3),
            "item_history_mask": torch.tensor([[0, 1, 1, 1]] * 3),
        }
        outputs = model(batch)
        self.assertEqual(tuple(outputs["purchase_logits"].shape), (3, 6))
        self.assertEqual(tuple(outputs["refund_logits"].shape), (3, 6))
        self.assertEqual(tuple(outputs["net_probability"].shape), (3,))
        self.assertTrue(torch.all(outputs["net_probability"] >= 0))
        self.assertTrue(torch.all(outputs["net_probability"] <= 1))


if __name__ == "__main__":
    unittest.main()
