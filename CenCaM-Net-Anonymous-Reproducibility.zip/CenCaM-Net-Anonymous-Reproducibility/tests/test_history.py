import unittest

from cencam.data.history import CausalHistoryBuilder


class HistoryTests(unittest.TestCase):
    def test_strict_past_and_bounded_lengths(self) -> None:
        builder = CausalHistoryBuilder(user_length=2, item_length=2)
        builder.append("u", "i", 10, "a", {"x": 1})
        builder.append("u", "i", 20, "b", {"x": 2})
        builder.append("u", "i", 30, "c", {"x": 3})
        result = builder.query("u", "i", 30)
        self.assertEqual([event.event_id for event in result["user_history"]], ["b"])
        self.assertEqual([event.event_id for event in result["item_history"]], ["b"])

    def test_chronology_guard(self) -> None:
        builder = CausalHistoryBuilder()
        builder.append("u", "i", 20, "a", None)
        with self.assertRaises(ValueError):
            builder.append("u", "i", 10, "b", None)


if __name__ == "__main__":
    unittest.main()
