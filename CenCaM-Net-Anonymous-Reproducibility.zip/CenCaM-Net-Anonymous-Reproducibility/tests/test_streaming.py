import unittest

import pandas as pd

from cencam.data.streaming import MaturityWindows, derive_maturity


class StreamingTests(unittest.TestCase):
    def test_stage_maturity(self) -> None:
        frame = pd.DataFrame(
            {
                "click_id": [1, 2],
                "user_id": [1, 2],
                "item_id": [1, 2],
                "click_time": pd.to_datetime(["2026-01-01", "2026-01-01"], utc=True),
                "payment_time": pd.to_datetime(["2026-01-02", None], utc=True),
                "refund_time": pd.to_datetime([None, None], utc=True),
            }
        )
        result = derive_maturity(
            frame,
            pd.Timestamp("2026-01-08", tz="UTC"),
            MaturityWindows(purchase_seconds=3 * 86400, refund_seconds=3 * 86400, hazard_intervals=12),
        )
        self.assertEqual(result["net_mature"].tolist(), [1, 1])
        self.assertEqual(result["net_label"].tolist(), [1, 0])
        self.assertTrue((result["purchase_censor_bin"] <= 11).all())


if __name__ == "__main__":
    unittest.main()
