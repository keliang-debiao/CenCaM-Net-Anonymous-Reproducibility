import unittest
from pathlib import Path

import yaml


class SplitGuardTests(unittest.TestCase):
    def test_held_out_days_are_disjoint(self) -> None:
        root = Path(__file__).resolve().parents[1]
        schedule = yaml.safe_load((root / "manifests/split_schedule.yaml").read_text())
        train = set(schedule["pretraining_days"])
        shadow = set(schedule["shadow_prediction_days"])
        replay = set(schedule["replay_days"])
        test = set(schedule["test_days"])
        self.assertFalse(train & shadow)
        self.assertFalse((train | shadow | replay) & test)
        self.assertLess(max(replay), min(test))
        self.assertLess(schedule["calibration_freeze_after_day"], min(test))


if __name__ == "__main__":
    unittest.main()
