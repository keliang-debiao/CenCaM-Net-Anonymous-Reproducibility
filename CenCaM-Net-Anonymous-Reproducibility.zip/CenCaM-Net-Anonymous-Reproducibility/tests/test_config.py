import unittest
from pathlib import Path

from cencam.config import load_config


class ConfigTests(unittest.TestCase):
    def test_inheritance_and_override(self) -> None:
        root = Path(__file__).resolve().parents[1]
        config = load_config(root / "configs/ablation.yaml", ["model.model_dim=64"])
        self.assertEqual(config["model"]["model_dim"], 64)
        self.assertEqual(config["run"]["name"], "cascade_ablation")
        self.assertEqual(config["data"]["history_policy"], "strictly_past")


if __name__ == "__main__":
    unittest.main()
