from __future__ import annotations

import pandas as pd


def scale_event_delays(
    frame: pd.DataFrame,
    purchase_scale: float = 1.0,
    refund_scale: float = 1.0,
) -> pd.DataFrame:
    if purchase_scale <= 0 or refund_scale <= 0:
        raise ValueError("Delay scales must be positive")
    result = frame.copy()
    purchase_delay = result["payment_time"] - result["click_time"]
    result["payment_time"] = result["click_time"] + purchase_delay * purchase_scale
    refund_delay = result["refund_time"] - frame["payment_time"]
    result["refund_time"] = result["payment_time"] + refund_delay * refund_scale
    return result
