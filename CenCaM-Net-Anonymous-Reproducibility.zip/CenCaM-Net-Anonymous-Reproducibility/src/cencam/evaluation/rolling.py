from __future__ import annotations

import numpy as np
import pandas as pd

from ..metrics import binary_metrics


def metrics_by_window(
    labels: np.ndarray,
    probabilities: np.ndarray,
    days: np.ndarray,
    mature: np.ndarray | None = None,
    bins: int = 15,
) -> pd.DataFrame:
    labels = np.asarray(labels)
    probabilities = np.asarray(probabilities)
    days = np.asarray(days)
    mature = np.ones(len(labels), dtype=bool) if mature is None else np.asarray(mature).astype(bool)
    if not (len(labels) == len(probabilities) == len(days) == len(mature)):
        raise ValueError("Evaluation arrays must have the same length")
    rows: list[dict[str, float | int]] = []
    for day in np.unique(days):
        mask = (days == day) & mature
        if not np.any(mask):
            continue
        row: dict[str, float | int] = {
            "day_index": int(day),
            "observations": int(mask.sum()),
            "prevalence": float(labels[mask].mean()),
        }
        row.update(binary_metrics(labels[mask], probabilities[mask], bins))
        rows.append(row)
    return pd.DataFrame(rows)
