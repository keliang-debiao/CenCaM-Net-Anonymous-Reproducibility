from __future__ import annotations

import argparse
import json
from pathlib import Path

from .config import load_config


def main() -> None:
    parser = argparse.ArgumentParser(description="CenCaM-Net repository utilities")
    subparsers = parser.add_subparsers(dest="command", required=True)
    resolve = subparsers.add_parser("resolve-config")
    resolve.add_argument("config", type=Path)
    resolve.add_argument("--set", action="append", default=[])
    arguments = parser.parse_args()
    if arguments.command == "resolve-config":
        print(json.dumps(load_config(arguments.config, arguments.set), indent=2))


if __name__ == "__main__":
    main()
