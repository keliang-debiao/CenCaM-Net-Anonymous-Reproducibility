from __future__ import annotations

import torch
from torch import nn


class RMSNorm(nn.Module):
    def __init__(self, dim: int, eps: float = 1e-6) -> None:
        super().__init__()
        self.weight = nn.Parameter(torch.ones(dim))
        self.eps = eps

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        scale = torch.rsqrt(x.pow(2).mean(dim=-1, keepdim=True) + self.eps)
        return x * scale * self.weight


class ResidualMLP(nn.Module):
    def __init__(self, dim: int, hidden_dim: int, dropout: float) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, dim),
            nn.Dropout(dropout),
        )
        self.norm = nn.LayerNorm(dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.norm(x + self.net(x))


class RelativeTimeEmbedding(nn.Module):
    def __init__(self, buckets: int, model_dim: int) -> None:
        super().__init__()
        self.embedding = nn.Embedding(buckets, model_dim)

    def forward(self, bucket: torch.Tensor) -> torch.Tensor:
        return self.embedding(bucket.long().clamp(0, self.embedding.num_embeddings - 1))


class SharedFieldTokenizer(nn.Module):
    def __init__(
        self,
        dense_input_dim: int,
        model_dim: int,
        categorical_cardinalities: list[int] | None = None,
        categorical_embedding_dim: int = 16,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()
        cardinalities = categorical_cardinalities or []
        self.embeddings = nn.ModuleList(
            [nn.Embedding(size, categorical_embedding_dim) for size in cardinalities]
        )
        total = dense_input_dim + len(cardinalities) * categorical_embedding_dim
        self.projection = nn.Sequential(
            nn.Linear(total, model_dim),
            nn.LayerNorm(model_dim),
            nn.Dropout(dropout),
        )

    def forward(
        self, dense: torch.Tensor, categorical: torch.Tensor | None = None
    ) -> torch.Tensor:
        features = [dense]
        if self.embeddings:
            if categorical is None:
                raise ValueError("categorical tensor is required by the tokenizer")
            if categorical.shape[-1] != len(self.embeddings):
                raise ValueError("categorical field count does not match the configuration")
            features.extend(
                embedding(categorical[..., index].long())
                for index, embedding in enumerate(self.embeddings)
            )
        return self.projection(torch.cat(features, dim=-1))
