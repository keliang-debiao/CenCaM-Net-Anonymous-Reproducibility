from __future__ import annotations

import torch
from torch import nn


class DiscreteHazardHead(nn.Module):
    def __init__(self, dim: int = 128, intervals: int = 12) -> None:
        super().__init__()
        self.linear = nn.Linear(dim, intervals)

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        logits = self.linear(x)
        hazards = torch.sigmoid(logits)
        event_probability = 1.0 - torch.prod(1.0 - hazards, dim=-1)
        return logits, event_probability


class CascadedHazardOutputs(nn.Module):
    def __init__(self, dim: int = 128, intervals: int = 12) -> None:
        super().__init__()
        self.purchase = DiscreteHazardHead(dim, intervals)
        self.refund = DiscreteHazardHead(dim, intervals)
        self.direct = nn.Linear(dim, 1)

    def forward(
        self, history: torch.Tensor, conversion: torch.Tensor, refund: torch.Tensor
    ) -> dict[str, torch.Tensor]:
        purchase_logits, purchase_probability = self.purchase(conversion)
        refund_logits, refund_probability = self.refund(refund)
        composed = purchase_probability * (1.0 - refund_probability)
        direct = torch.sigmoid(self.direct(history)).squeeze(-1)
        return {
            "purchase_logits": purchase_logits,
            "refund_logits": refund_logits,
            "purchase_probability": purchase_probability,
            "refund_probability": refund_probability,
            "net_probability": composed,
            "direct_net_probability": direct,
        }


class MatureBinaryOutputs(nn.Module):
    def __init__(self, dim: int = 128) -> None:
        super().__init__()
        self.purchase = nn.Linear(dim, 1)
        self.refund = nn.Linear(dim, 1)
        self.direct = nn.Linear(dim, 1)

    def forward(
        self, history: torch.Tensor, conversion: torch.Tensor, refund: torch.Tensor
    ) -> dict[str, torch.Tensor]:
        purchase_logits = self.purchase(conversion)
        refund_logits = self.refund(refund)
        purchase_probability = torch.sigmoid(purchase_logits).squeeze(-1)
        refund_probability = torch.sigmoid(refund_logits).squeeze(-1)
        return {
            "purchase_logits": purchase_logits,
            "refund_logits": refund_logits,
            "purchase_probability": purchase_probability,
            "refund_probability": refund_probability,
            "net_probability": purchase_probability * (1.0 - refund_probability),
            "direct_net_probability": torch.sigmoid(self.direct(history)).squeeze(-1),
        }
