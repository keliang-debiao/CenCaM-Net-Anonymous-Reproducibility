from __future__ import annotations

import torch
from torch import nn

from .hazards import CascadedHazardOutputs


class MatchedMLPCascade(nn.Module):
    def __init__(self, input_dim: int, model_dim: int = 128, depth: int = 4) -> None:
        super().__init__()
        layers: list[nn.Module] = [nn.Linear(input_dim, model_dim), nn.GELU()]
        for _ in range(depth - 1):
            layers.extend([nn.Linear(model_dim, model_dim), nn.GELU()])
        self.backbone = nn.Sequential(*layers)
        self.heads = CascadedHazardOutputs(model_dim, 12)

    def forward(self, x: torch.Tensor) -> dict[str, torch.Tensor]:
        h = self.backbone(x)
        return self.heads(h, h, h)


class LSTMCascade(nn.Module):
    def __init__(self, input_dim: int, model_dim: int = 128, layers: int = 4) -> None:
        super().__init__()
        self.encoder = nn.LSTM(
            input_dim, model_dim, num_layers=layers, batch_first=True, dropout=0.1
        )
        self.heads = CascadedHazardOutputs(model_dim, 12)

    def forward(self, sequence: torch.Tensor) -> dict[str, torch.Tensor]:
        encoded, _ = self.encoder(sequence)
        h = encoded[:, -1]
        return self.heads(h, h, h)

