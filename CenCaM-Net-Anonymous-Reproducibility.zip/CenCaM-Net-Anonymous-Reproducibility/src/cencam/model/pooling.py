from __future__ import annotations

import math

import torch
from torch import nn


class CurrentClickGuidedPooling(nn.Module):
    def __init__(self, model_dim: int = 128, key_dim: int = 128) -> None:
        super().__init__()
        self.query = nn.Linear(model_dim, key_dim, bias=False)
        self.key = nn.Linear(model_dim, key_dim, bias=False)
        self.scale = math.sqrt(key_dim)

    def forward(
        self, current: torch.Tensor, history: torch.Tensor, mask: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        scores = torch.einsum("bd,btd->bt", self.query(current), self.key(history)) / self.scale
        scores = scores.masked_fill(~mask.bool(), torch.finfo(scores.dtype).min)
        all_missing = ~mask.bool().any(dim=1)
        scores = torch.where(all_missing[:, None], torch.zeros_like(scores), scores)
        weights = torch.softmax(scores, dim=1)
        weights = torch.where(all_missing[:, None], torch.zeros_like(weights), weights)
        pooled = torch.einsum("bt,btd->bd", weights, history)
        return pooled, weights

