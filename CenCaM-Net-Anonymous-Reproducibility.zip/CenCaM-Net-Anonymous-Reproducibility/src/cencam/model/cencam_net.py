from __future__ import annotations

from typing import Any

import torch
from torch import nn

from .experts import AsymmetricSharedPrivateExperts
from .grouped_ssm import GroupedComplexEncoder, PointwiseMLPEncoder, RecurrentSequenceEncoder
from .hazards import CascadedHazardOutputs, MatureBinaryOutputs
from .layers import RelativeTimeEmbedding, ResidualMLP, SharedFieldTokenizer
from .pooling import CurrentClickGuidedPooling


class CenCaMNet(nn.Module):
    def __init__(self, config: dict[str, Any]) -> None:
        super().__init__()
        dim = int(config.get("model_dim", 128))
        input_dim = int(config.get("dense_input_dim", 64))
        cardinalities = list(config.get("categorical_cardinalities", []))
        embedding_dim = int(config.get("categorical_embedding_dim", 16))
        dropout = float(config.get("dropout", 0.1))
        groups = int(config.get("ssm_groups", 4))
        states = int(config.get("complex_states_per_group", 16))
        layers = int(config.get("encoder_layers", 4))
        convolution_width = int(config.get("convolution_width", 4))

        self.tokenizer = SharedFieldTokenizer(
            dense_input_dim=input_dim,
            model_dim=dim,
            categorical_cardinalities=cardinalities,
            categorical_embedding_dim=embedding_dim,
            dropout=dropout,
        )
        encoder_args = dict(
            model_dim=dim,
            layers=layers,
            groups=groups,
            states_per_group=states,
            convolution_width=convolution_width,
            dropout=dropout,
        )
        encoder_type = str(config.get("encoder_type", "grouped_complex")).lower()
        encoder_class = {
            "grouped_complex": GroupedComplexEncoder,
            "mlp": PointwiseMLPEncoder,
            "lstm": RecurrentSequenceEncoder,
            "xlstm": RecurrentSequenceEncoder,
            "mamba2": GroupedComplexEncoder,
        }.get(encoder_type)
        if encoder_class is None:
            raise ValueError(
                f"Unsupported encoder_type={encoder_type}; use a registered baseline adapter"
            )
        if encoder_type == "mamba2":
            encoder_args["groups"] = 1
        self.user_encoder = encoder_class(**encoder_args)
        self.item_encoder = encoder_class(**encoder_args)
        self.use_user_history = bool(config.get("use_user_history", True))
        self.use_item_history = bool(config.get("use_item_history", True))
        self.use_relative_time = bool(config.get("use_relative_time", True))
        time_buckets = int(config.get("relative_time_buckets", 64))
        self.user_time = RelativeTimeEmbedding(time_buckets, dim)
        self.item_time = RelativeTimeEmbedding(time_buckets, dim)
        self.user_pool = CurrentClickGuidedPooling(dim, dim)
        self.item_pool = CurrentClickGuidedPooling(dim, dim)
        self.fusion = nn.Sequential(nn.Linear(dim * 3, dim), nn.LayerNorm(dim))
        self.router_type = str(config.get("router_type", "asymmetric_shared_private"))
        if self.router_type == "asymmetric_shared_private":
            self.experts = AsymmetricSharedPrivateExperts(
                dim=dim,
                shared_count=int(config.get("shared_experts", 4)),
                private_count=int(config.get("private_experts_per_stage", 2)),
                hidden_dim=int(config.get("expert_hidden_dim", 256)),
                top_k=int(config.get("top_k_experts", 2)),
                dropout=dropout,
                conversion_to_refund_transfer=bool(
                    config.get("conversion_to_refund_transfer", True)
                ),
            )
        elif self.router_type == "shared_bottom":
            self.shared_bottom = ResidualMLP(dim, int(config.get("expert_hidden_dim", 256)), dropout)
        elif self.router_type == "separate":
            hidden = int(config.get("expert_hidden_dim", 256))
            self.conversion_tower = ResidualMLP(dim, hidden, dropout)
            self.refund_tower = ResidualMLP(dim, hidden, dropout)
        else:
            raise ValueError(f"Unsupported router_type={self.router_type}")
        if str(config.get("hazard_type", "discrete_hazard")) == "mature_binary":
            self.outputs = MatureBinaryOutputs(dim=dim)
        else:
            self.outputs = CascadedHazardOutputs(
                dim=dim, intervals=int(config.get("hazard_intervals", 12))
            )

    def forward(self, batch: dict[str, torch.Tensor]) -> dict[str, torch.Tensor]:
        current = self.tokenizer(batch["current_dense"], batch.get("current_categorical"))
        user_tokens = self.tokenizer(
            batch["user_history_dense"], batch.get("user_history_categorical")
        )
        item_tokens = self.tokenizer(
            batch["item_history_dense"], batch.get("item_history_categorical")
        )
        user_mask = batch["user_history_mask"].bool()
        item_mask = batch["item_history_mask"].bool()
        if not self.use_user_history:
            user_mask = torch.zeros_like(user_mask)
        if not self.use_item_history:
            item_mask = torch.zeros_like(item_mask)
        if self.use_relative_time:
            user_bucket = batch.get(
                "user_history_delay_bucket", torch.zeros_like(user_mask, dtype=torch.long)
            )
            item_bucket = batch.get(
                "item_history_delay_bucket", torch.zeros_like(item_mask, dtype=torch.long)
            )
            user_tokens = user_tokens + self.user_time(user_bucket)
            item_tokens = item_tokens + self.item_time(item_bucket)
        user_encoded = self.user_encoder(user_tokens, user_mask)
        item_encoded = self.item_encoder(item_tokens, item_mask)
        user_pooled, user_attention = self.user_pool(current, user_encoded, user_mask)
        item_pooled, item_attention = self.item_pool(current, item_encoded, item_mask)
        history = self.fusion(torch.cat([current, user_pooled, item_pooled], dim=-1))
        if self.router_type == "asymmetric_shared_private":
            routed = self.experts(history)
        elif self.router_type == "shared_bottom":
            shared = self.shared_bottom(history)
            routed = {
                "conversion": shared,
                "refund": shared,
                "gamma": torch.zeros_like(shared[:, :1]),
                "balance_loss": shared.new_zeros(()),
            }
        else:
            routed = {
                "conversion": self.conversion_tower(history),
                "refund": self.refund_tower(history),
                "gamma": torch.zeros_like(history[:, :1]),
                "balance_loss": history.new_zeros(()),
            }
        output = self.outputs(history, routed["conversion"], routed["refund"])
        output.update(routed)
        output["history"] = history
        output["user_attention"] = user_attention
        output["item_attention"] = item_attention
        return output
