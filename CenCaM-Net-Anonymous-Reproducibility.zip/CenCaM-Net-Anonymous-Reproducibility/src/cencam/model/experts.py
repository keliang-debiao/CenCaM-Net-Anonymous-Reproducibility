from __future__ import annotations

import torch
from torch import nn

from .layers import ResidualMLP


class TopKRouter(nn.Module):
    def __init__(self, dim: int, expert_count: int, top_k: int = 2) -> None:
        super().__init__()
        if top_k > expert_count:
            raise ValueError("top_k cannot exceed expert_count")
        self.gate = nn.Linear(dim, expert_count)
        self.expert_count = expert_count
        self.top_k = top_k

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        logits = self.gate(x)
        values, indices = torch.topk(logits, self.top_k, dim=-1)
        selected = torch.softmax(values, dim=-1)
        weights = torch.zeros_like(logits)
        return weights.scatter(-1, indices, selected)


class StageExpertBank(nn.Module):
    def __init__(
        self,
        shared_experts: nn.ModuleList,
        dim: int,
        private_count: int,
        hidden_dim: int,
        top_k: int,
        dropout: float,
    ) -> None:
        super().__init__()
        self.shared_experts = shared_experts
        self.private_experts = nn.ModuleList(
            [ResidualMLP(dim, hidden_dim, dropout) for _ in range(private_count)]
        )
        self.router = TopKRouter(dim, len(shared_experts) + private_count, top_k)

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        outputs = [expert(x) for expert in self.shared_experts]
        outputs.extend(expert(x) for expert in self.private_experts)
        stacked = torch.stack(outputs, dim=1)
        weights = self.router(x)
        mixed = torch.einsum("be,bed->bd", weights, stacked)
        load = weights.mean(dim=0)
        uniform = torch.full_like(load, 1.0 / load.numel())
        balance_loss = torch.mean((load - uniform) ** 2)
        return mixed, weights, balance_loss


class AsymmetricSharedPrivateExperts(nn.Module):
    def __init__(
        self,
        dim: int = 128,
        shared_count: int = 4,
        private_count: int = 2,
        hidden_dim: int = 256,
        top_k: int = 2,
        dropout: float = 0.1,
        conversion_to_refund_transfer: bool = True,
    ) -> None:
        super().__init__()
        shared = nn.ModuleList(
            [ResidualMLP(dim, hidden_dim, dropout) for _ in range(shared_count)]
        )
        self.conversion = StageExpertBank(
            shared, dim, private_count, hidden_dim, top_k, dropout
        )
        self.refund = StageExpertBank(shared, dim, private_count, hidden_dim, top_k, dropout)
        self.transfer_gate = nn.Linear(dim, 1)
        self.transfer = nn.Linear(dim, dim, bias=False)
        self.conversion_to_refund_transfer = conversion_to_refund_transfer

    def forward(self, x: torch.Tensor) -> dict[str, torch.Tensor]:
        conversion, conversion_weights, conversion_balance = self.conversion(x)
        refund_base, refund_weights, refund_balance = self.refund(x)
        if self.conversion_to_refund_transfer:
            gamma = torch.sigmoid(self.transfer_gate(x))
            refund = refund_base + gamma * self.transfer(conversion)
        else:
            gamma = torch.zeros_like(self.transfer_gate(x))
            refund = refund_base
        return {
            "conversion": conversion,
            "refund": refund,
            "gamma": gamma,
            "conversion_weights": conversion_weights,
            "refund_weights": refund_weights,
            "balance_loss": conversion_balance + refund_balance,
        }
