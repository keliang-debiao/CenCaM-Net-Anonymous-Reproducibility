from __future__ import annotations

import torch
import torch.nn.functional as F
from torch import nn

from .layers import RMSNorm, ResidualMLP


class PointwiseMLPEncoder(nn.Module):
    def __init__(self, model_dim: int, layers: int, dropout: float = 0.1, **_: object) -> None:
        super().__init__()
        self.layers = nn.ModuleList(
            [ResidualMLP(model_dim, model_dim * 2, dropout) for _ in range(layers)]
        )
        self.final_norm = RMSNorm(model_dim)

    def forward(self, x: torch.Tensor, mask: torch.Tensor | None = None) -> torch.Tensor:
        for layer in self.layers:
            x = layer(x)
        if mask is not None:
            x = x * mask.unsqueeze(-1).to(x.dtype)
        return self.final_norm(x)


class RecurrentSequenceEncoder(nn.Module):
    def __init__(self, model_dim: int, layers: int, dropout: float = 0.1, **_: object) -> None:
        super().__init__()
        self.recurrent = nn.LSTM(
            model_dim,
            model_dim,
            num_layers=layers,
            batch_first=True,
            dropout=dropout if layers > 1 else 0.0,
        )
        self.final_norm = RMSNorm(model_dim)

    def forward(self, x: torch.Tensor, mask: torch.Tensor | None = None) -> torch.Tensor:
        output, _ = self.recurrent(x)
        if mask is not None:
            output = output * mask.unsqueeze(-1).to(output.dtype)
        return self.final_norm(output)


class GroupedComplexSSMLayer(nn.Module):
    """Reference grouped complex-state recurrence with data-dependent MIMO maps."""

    def __init__(
        self,
        model_dim: int = 128,
        groups: int = 4,
        states_per_group: int = 16,
        convolution_width: int = 4,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()
        if model_dim % groups:
            raise ValueError("model_dim must be divisible by groups")
        self.model_dim = model_dim
        self.groups = groups
        self.group_dim = model_dim // groups
        self.states_per_group = states_per_group
        self.convolution_width = convolution_width

        self.norm = RMSNorm(model_dim)
        self.local_conv = nn.Conv1d(
            model_dim,
            model_dim,
            kernel_size=convolution_width,
            groups=model_dim,
            bias=True,
        )
        self.input_projection = nn.Linear(model_dim, model_dim)
        self.u_projection = nn.Linear(model_dim, model_dim)
        self.delta_projection = nn.Linear(model_dim, groups)
        self.mix_projection = nn.Linear(model_dim, groups)
        self.phase_projection = nn.Linear(model_dim, groups * states_per_group)
        map_dim = groups * states_per_group * self.group_dim
        self.input_map_projection = nn.Linear(model_dim, map_dim)
        self.readout_map_projection = nn.Linear(model_dim, map_dim)
        self.log_decay = nn.Parameter(torch.zeros(groups, states_per_group))
        self.direct = nn.Parameter(torch.ones(groups, self.group_dim))
        self.output_projection = nn.Linear(model_dim, model_dim)
        self.dropout = nn.Dropout(dropout)

    def _causal_conv(self, x: torch.Tensor) -> torch.Tensor:
        x_t = x.transpose(1, 2)
        x_t = F.pad(x_t, (self.convolution_width - 1, 0))
        return self.local_conv(x_t).transpose(1, 2)

    def forward(self, x: torch.Tensor, mask: torch.Tensor | None = None) -> torch.Tensor:
        batch, length, _ = x.shape
        z = self.norm(x)
        z = F.silu(self.input_projection(z) + self._causal_conv(z))
        u = self.u_projection(z).view(batch, length, self.groups, self.group_dim)
        delta = F.softplus(self.delta_projection(z)).unsqueeze(-1)
        mix = torch.sigmoid(self.mix_projection(z)).unsqueeze(-1)
        phase = self.phase_projection(z).view(
            batch, length, self.groups, self.states_per_group
        )
        decay = F.softplus(self.log_decay).view(1, self.groups, self.states_per_group)

        state = torch.zeros(
            batch,
            self.groups,
            self.states_per_group,
            device=x.device,
            dtype=torch.complex64,
        )
        previous_input = torch.zeros(
            batch,
            self.groups,
            self.states_per_group,
            device=x.device,
            dtype=x.dtype,
        )
        outputs: list[torch.Tensor] = []

        for step in range(length):
            z_step = z[:, step]
            b_map = self.input_map_projection(z_step).view(
                batch, self.groups, self.states_per_group, self.group_dim
            )
            c_map = self.readout_map_projection(z_step).view(
                batch, self.groups, self.states_per_group, self.group_dim
            )
            current_input = torch.einsum("bgnk,bgk->bgn", b_map, u[:, step])
            mixed_input = (
                (1.0 - mix[:, step]) * previous_input + mix[:, step] * current_input
            )
            rho = torch.exp(-delta[:, step] * decay)
            transition = torch.polar(rho.float(), phase[:, step].float())
            proposal = transition * state + delta[:, step].to(torch.complex64) * torch.complex(
                mixed_input.float(), torch.zeros_like(mixed_input.float())
            )
            if mask is not None:
                valid = mask[:, step].view(batch, 1, 1).bool()
                state = torch.where(valid, proposal, state)
            else:
                state = proposal
            readout = torch.einsum("bgnk,bgn->bgk", c_map.to(torch.complex64), state).real
            readout = readout.to(x.dtype) + self.direct * u[:, step]
            if mask is not None:
                readout = readout * mask[:, step].view(batch, 1, 1).to(readout.dtype)
            outputs.append(readout.reshape(batch, self.model_dim))
            previous_input = current_input

        y = torch.stack(outputs, dim=1)
        return x + self.dropout(self.output_projection(y))


class GroupedComplexEncoder(nn.Module):
    def __init__(
        self,
        model_dim: int = 128,
        layers: int = 4,
        groups: int = 4,
        states_per_group: int = 16,
        convolution_width: int = 4,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()
        self.layers = nn.ModuleList(
            [
                GroupedComplexSSMLayer(
                    model_dim=model_dim,
                    groups=groups,
                    states_per_group=states_per_group,
                    convolution_width=convolution_width,
                    dropout=dropout,
                )
                for _ in range(layers)
            ]
        )
        self.final_norm = RMSNorm(model_dim)

    def forward(self, x: torch.Tensor, mask: torch.Tensor | None = None) -> torch.Tensor:
        for layer in self.layers:
            x = layer(x, mask)
        return self.final_norm(x)
