"""CenCaM-Net model components."""

from .cencam_net import CenCaMNet

__all__ = ["CenCaMNet"]

