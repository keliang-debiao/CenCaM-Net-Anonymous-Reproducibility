from __future__ import annotations

import copy
from pathlib import Path
from typing import Any, Iterable

import yaml


def _deep_merge(base: dict[str, Any], update: dict[str, Any]) -> dict[str, Any]:
    merged = copy.deepcopy(base)
    for key, value in update.items():
        if key in merged and isinstance(merged[key], dict) and isinstance(value, dict):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = copy.deepcopy(value)
    return merged


def _parse_scalar(value: str) -> Any:
    parsed = yaml.safe_load(value)
    return parsed


def set_by_path(config: dict[str, Any], key: str, value: Any) -> None:
    cursor = config
    parts = key.split(".")
    for part in parts[:-1]:
        cursor = cursor.setdefault(part, {})
    cursor[parts[-1]] = value


def load_config(path: str | Path, overrides: Iterable[str] = ()) -> dict[str, Any]:
    path = Path(path).resolve()
    with path.open("r", encoding="utf-8") as handle:
        current = yaml.safe_load(handle) or {}
    parent_ref = current.pop("inherits", None)
    if parent_ref:
        parent_path = Path(parent_ref)
        if not parent_path.is_absolute():
            repository_root = path.parent.parent
            parent_path = repository_root / parent_path
        base = load_config(parent_path)
        current = _deep_merge(base, current)
    for item in overrides:
        if "=" not in item:
            raise ValueError(f"Override must use key=value syntax: {item}")
        key, value = item.split("=", 1)
        set_by_path(current, key, _parse_scalar(value))
    return current


def save_resolved_config(config: dict[str, Any], path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        yaml.safe_dump(config, handle, sort_keys=False)

