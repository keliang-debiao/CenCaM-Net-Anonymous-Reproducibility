from __future__ import annotations

from typing import Any

import torch
import torch.nn.functional as F


def discrete_hazard_nll(
    logits: torch.Tensor,
    event_bin: torch.Tensor,
    event_observed: torch.Tensor,
    censor_bin: torch.Tensor,
    eligible: torch.Tensor | None = None,
) -> torch.Tensor:
    """Negative log-likelihood for discrete events with right censoring."""

    log_hazard = F.logsigmoid(logits)
    log_survival = F.logsigmoid(-logits)
    intervals = logits.shape[-1]
    positions = torch.arange(intervals, device=logits.device).view(1, -1)
    event_bin = event_bin.long().view(-1, 1)
    censor_bin = censor_bin.long().view(-1, 1)
    observed = event_observed.bool().view(-1, 1)

    before_event = positions < event_bin
    at_event = positions == event_bin
    through_censor = positions <= censor_bin
    observed_ll = (log_survival * before_event).sum(dim=-1) + (
        log_hazard * at_event
    ).sum(dim=-1)
    censored_ll = (log_survival * through_censor).sum(dim=-1)
    log_likelihood = torch.where(observed.squeeze(-1), observed_ll, censored_ll)
    if eligible is not None:
        weights = eligible.to(log_likelihood.dtype)
        return -(log_likelihood * weights).sum() / weights.sum().clamp_min(1.0)
    return -log_likelihood.mean()


def pairwise_ranking_loss(
    scores: torch.Tensor,
    pair_indices: torch.Tensor,
    pair_weights: torch.Tensor | None = None,
) -> torch.Tensor:
    if pair_indices.numel() == 0:
        return scores.new_zeros(())
    positive = scores[pair_indices[:, 0].long()]
    negative = scores[pair_indices[:, 1].long()]
    losses = F.softplus(-(positive - negative))
    if pair_weights is not None:
        weights = pair_weights.to(losses.dtype)
        return (losses * weights).sum() / weights.sum().clamp_min(1.0)
    return losses.mean()


def coral_loss(source: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    if source.shape[0] < 2 or target.shape[0] < 2:
        return source.new_zeros(())
    source_centered = source - source.mean(dim=0, keepdim=True)
    target_centered = target - target.mean(dim=0, keepdim=True)
    source_cov = source_centered.T @ source_centered / (source.shape[0] - 1)
    target_cov = target_centered.T @ target_centered / (target.shape[0] - 1)
    dim = source.shape[-1]
    return torch.sum((source_cov - target_cov) ** 2) / (4.0 * dim * dim)


def compute_objective(
    outputs: dict[str, torch.Tensor],
    batch: dict[str, torch.Tensor],
    weights: dict[str, float],
) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
    refund_eligible = batch["purchase_observed"].bool()
    if outputs["purchase_logits"].shape[-1] == 1:
        purchase_target = batch["purchase_observed"].to(outputs["purchase_logits"].dtype)
        purchase_mask = batch["purchase_mature"].to(outputs["purchase_logits"].dtype)
        purchase_terms = F.binary_cross_entropy_with_logits(
            outputs["purchase_logits"].squeeze(-1), purchase_target, reduction="none"
        )
        purchase_loss = (purchase_terms * purchase_mask).sum() / purchase_mask.sum().clamp_min(1.0)
        refund_target = batch["refund_observed"].to(outputs["refund_logits"].dtype)
        refund_mask = (
            batch["refund_mature"].bool() & refund_eligible
        ).to(outputs["refund_logits"].dtype)
        refund_terms = F.binary_cross_entropy_with_logits(
            outputs["refund_logits"].squeeze(-1), refund_target, reduction="none"
        )
        refund_loss = (refund_terms * refund_mask).sum() / refund_mask.sum().clamp_min(1.0)
    else:
        purchase_loss = discrete_hazard_nll(
            outputs["purchase_logits"],
            batch["purchase_event_bin"],
            batch["purchase_observed"],
            batch["purchase_censor_bin"],
        )
        refund_loss = discrete_hazard_nll(
            outputs["refund_logits"],
            batch["refund_event_bin"],
            batch["refund_observed"],
            batch["refund_censor_bin"],
            eligible=refund_eligible,
        )
    mature = batch["net_mature"].to(outputs["net_probability"].dtype)
    target = batch["net_label"].to(outputs["net_probability"].dtype)
    direct = F.binary_cross_entropy(
        outputs["direct_net_probability"].clamp(1e-6, 1 - 1e-6),
        target,
        reduction="none",
    )
    direct = (direct * mature).sum() / mature.sum().clamp_min(1.0)
    consistency = F.mse_loss(
        outputs["direct_net_probability"], outputs["net_probability"].detach()
    )
    brier = (((outputs["net_probability"] - target) ** 2) * mature).sum() / mature.sum().clamp_min(
        1.0
    )
    ranking = outputs["net_probability"].new_zeros(())
    if "ranking_pairs" in batch:
        ranking = pairwise_ranking_loss(
            outputs["net_probability"],
            batch["ranking_pairs"],
            batch.get("ranking_pair_weights"),
        )
    temporal = outputs["net_probability"].new_zeros(())
    if "temporal_source_mask" in batch and "temporal_target_mask" in batch:
        source_mask = batch["temporal_source_mask"].bool()
        target_mask = batch["temporal_target_mask"].bool()
        temporal = coral_loss(outputs["history"][source_mask], outputs["history"][target_mask])
    components = {
        "purchase_hazard": purchase_loss,
        "refund_hazard": refund_loss,
        "direct_netcvr": direct,
        "ranking": ranking,
        "cascade_consistency": consistency,
        "brier": brier,
        "temporal_invariance": temporal,
        "expert_balance": outputs.get("balance_loss", brier.new_zeros(())),
    }
    total = sum(float(weights.get(name, 0.0)) * value for name, value in components.items())
    return total, components
