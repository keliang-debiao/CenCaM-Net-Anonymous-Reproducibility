"""CenCaM-Net anonymous reproducibility package."""

__version__ = "1.0.0"

