from __future__ import annotations

import math
import time
from collections.abc import Iterable
from pathlib import Path
from typing import Any

import numpy as np

from ..metrics import binary_metrics
from ..reproducibility import sha256_file, write_json


def _torch():
    try:
        import torch
    except ImportError as exc:
        raise RuntimeError("Training requires the pinned PyTorch dependency") from exc
    return torch


def parameter_count(model: Any) -> int:
    return int(sum(parameter.numel() for parameter in model.parameters()))


def _to_device(batch: dict[str, Any], device: Any) -> dict[str, Any]:
    torch = _torch()
    return {
        key: value.to(device, non_blocking=True) if torch.is_tensor(value) else value
        for key, value in batch.items()
    }


def _precision_context(device: Any, precision: str):
    torch = _torch()
    enabled = device.type == "cuda" and precision in {"bf16", "fp16"}
    dtype = torch.bfloat16 if precision == "bf16" else torch.float16
    return torch.autocast(device_type=device.type, dtype=dtype, enabled=enabled)


def _scheduler(optimizer: Any, total_steps: int, warmup_fraction: float):
    torch = _torch()
    warmup_steps = max(1, round(total_steps * warmup_fraction))

    def multiplier(step: int) -> float:
        if step < warmup_steps:
            return max(1e-8, step / warmup_steps)
        progress = (step - warmup_steps) / max(1, total_steps - warmup_steps)
        return 0.5 * (1.0 + math.cos(math.pi * min(progress, 1.0)))

    return torch.optim.lr_scheduler.LambdaLR(optimizer, multiplier)


def train_epoch(
    model: Any,
    loader: Iterable[dict[str, Any]],
    optimizer: Any,
    scheduler: Any,
    device: Any,
    precision: str,
    loss_weights: dict[str, float],
    gradient_clip_norm: float,
) -> dict[str, float]:
    torch = _torch()
    from ..losses import compute_objective

    model.train()
    totals: dict[str, float] = {}
    observations = 0
    started = time.perf_counter()
    for batch in loader:
        batch = _to_device(batch, device)
        optimizer.zero_grad(set_to_none=True)
        with _precision_context(device, precision):
            outputs = model(batch)
            loss, components = compute_objective(outputs, batch, loss_weights)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), gradient_clip_norm)
        optimizer.step()
        scheduler.step()
        size = int(batch["current_dense"].shape[0])
        observations += size
        totals["loss"] = totals.get("loss", 0.0) + float(loss.detach()) * size
        for name, value in components.items():
            totals[name] = totals.get(name, 0.0) + float(value.detach()) * size
    elapsed = max(time.perf_counter() - started, 1e-9)
    result = {name: value / max(observations, 1) for name, value in totals.items()}
    result["observations"] = float(observations)
    result["samples_per_second"] = observations / elapsed
    return result


def evaluate_loader(
    model: Any,
    loader: Iterable[dict[str, Any]],
    device: Any,
    precision: str = "bf16",
    bins: int = 15,
) -> tuple[dict[str, float], dict[str, np.ndarray]]:
    torch = _torch()
    model.eval()
    collected: dict[str, list[np.ndarray]] = {
        "probability": [],
        "label": [],
        "mature": [],
        "day_index": [],
        "click_id": [],
    }
    with torch.no_grad():
        for batch in loader:
            batch = _to_device(batch, device)
            with _precision_context(device, precision):
                outputs = model(batch)
            collected["probability"].append(
                outputs["net_probability"].detach().float().cpu().numpy()
            )
            collected["label"].append(batch["net_label"].detach().cpu().numpy())
            collected["mature"].append(batch["net_mature"].detach().cpu().numpy())
            for optional in ("day_index", "click_id"):
                if optional in batch:
                    collected[optional].append(batch[optional].detach().cpu().numpy())
    arrays = {
        name: np.concatenate(parts) if parts else np.empty(0)
        for name, parts in collected.items()
    }
    mature = arrays["mature"].astype(bool)
    metrics = binary_metrics(arrays["label"][mature], arrays["probability"][mature], bins)
    metrics["mature_observations"] = int(mature.sum())
    return metrics, arrays


def fit_model(
    model: Any,
    train_loader: Any,
    validation_loader: Any,
    config: dict[str, Any],
    output_dir: str | Path,
    event_writer: Any | None = None,
) -> dict[str, Any]:
    torch = _torch()
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    run = config["run"]
    optimization = config["optimization"]
    requested_device = str(run.get("device", "cuda"))
    device = torch.device(
        "cuda" if requested_device == "cuda" and torch.cuda.is_available() else "cpu"
    )
    model.to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=float(optimization["learning_rate"]),
        weight_decay=float(optimization["weight_decay"]),
    )
    epochs = int(optimization["maximum_epochs"])
    schedule = _scheduler(
        optimizer,
        total_steps=max(1, epochs * len(train_loader)),
        warmup_fraction=float(optimization.get("warmup_fraction", 0.05)),
    )
    patience = int(optimization.get("early_stopping_patience", 5))
    best_pr_auc = -float("inf")
    best_nll = float("inf")
    best_epoch = 0
    stale_epochs = 0
    history: list[dict[str, Any]] = []
    checkpoint = output_dir / "checkpoint.pt"

    for epoch in range(1, epochs + 1):
        train_metrics = train_epoch(
            model,
            train_loader,
            optimizer,
            schedule,
            device,
            str(run.get("precision", "bf16")),
            config["loss"],
            float(optimization.get("gradient_clip_norm", 1.0)),
        )
        validation_metrics, _ = evaluate_loader(
            model,
            validation_loader,
            device,
            str(run.get("precision", "bf16")),
            int(config.get("calibration", {}).get("bins", 15)),
        )
        record = {
            "event": "epoch_completed",
            "epoch": epoch,
            "train": train_metrics,
            "validation": validation_metrics,
        }
        history.append(record)
        if event_writer is not None:
            event_writer(record)
        pr_auc = validation_metrics["pr_auc"]
        nll = validation_metrics["nll"]
        improved = pr_auc > best_pr_auc or (pr_auc == best_pr_auc and nll < best_nll)
        if improved:
            best_pr_auc, best_nll, best_epoch = pr_auc, nll, epoch
            stale_epochs = 0
            torch.save(
                {
                    "model_state": model.state_dict(),
                    "optimizer_state": optimizer.state_dict(),
                    "epoch": epoch,
                    "validation": validation_metrics,
                    "config": config,
                },
                checkpoint,
            )
        else:
            stale_epochs += 1
        if stale_epochs >= patience:
            break

    report = {
        "best_epoch": best_epoch,
        "best_validation_pr_auc": best_pr_auc,
        "best_validation_nll": best_nll,
        "parameters": parameter_count(model),
        "device": str(device),
        "checkpoint": checkpoint.name,
        "checkpoint_sha256": sha256_file(checkpoint),
        "history": history,
    }
    write_json(report, output_dir / "training_summary.json")
    return report
