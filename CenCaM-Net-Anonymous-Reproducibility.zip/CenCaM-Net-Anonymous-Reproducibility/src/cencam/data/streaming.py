from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class MaturityWindows:
    purchase_seconds: int = 3 * 86400
    refund_seconds: int = 3 * 86400
    hazard_intervals: int = 12


def _seconds(delta: pd.Series) -> np.ndarray:
    return delta.dt.total_seconds().to_numpy(dtype=np.float64)


def _event_bin(delays: np.ndarray, window_seconds: int, intervals: int) -> np.ndarray:
    width = window_seconds / intervals
    values = np.floor(np.maximum(delays, 0.0) / width).astype(np.int64)
    return np.clip(values, 0, intervals - 1)


def derive_maturity(
    frame: pd.DataFrame,
    observation_time: pd.Timestamp,
    windows: MaturityWindows = MaturityWindows(),
) -> pd.DataFrame:
    result = frame.copy()
    click_age = _seconds(observation_time - result["click_time"])
    purchase_delay = _seconds(result["payment_time"] - result["click_time"])
    purchase_observed = result["payment_time"].notna().to_numpy() & (
        result["payment_time"] <= observation_time
    ).to_numpy()
    purchase_mature = purchase_observed | (click_age >= windows.purchase_seconds)

    payment_age = np.full(len(result), -1.0, dtype=np.float64)
    has_payment = result["payment_time"].notna().to_numpy()
    payment_age[has_payment] = _seconds(
        observation_time - result.loc[has_payment, "payment_time"]
    )
    refund_delay = _seconds(result["refund_time"] - result["payment_time"])
    refund_observed = result["refund_time"].notna().to_numpy() & (
        result["refund_time"] <= observation_time
    ).to_numpy()
    refund_mature = has_payment & (refund_observed | (payment_age >= windows.refund_seconds))

    result["purchase_observed"] = purchase_observed.astype(np.int8)
    result["purchase_mature"] = purchase_mature.astype(np.int8)
    result["refund_observed"] = refund_observed.astype(np.int8)
    result["refund_mature"] = refund_mature.astype(np.int8)
    result["purchase_event_bin"] = _event_bin(
        np.nan_to_num(purchase_delay, nan=windows.purchase_seconds),
        windows.purchase_seconds,
        windows.hazard_intervals,
    )
    result["refund_event_bin"] = _event_bin(
        np.nan_to_num(refund_delay, nan=windows.refund_seconds),
        windows.refund_seconds,
        windows.hazard_intervals,
    )
    result["purchase_censor_bin"] = _event_bin(
        np.minimum(np.maximum(click_age, 0.0), windows.purchase_seconds),
        windows.purchase_seconds,
        windows.hazard_intervals,
    )
    refund_follow_up = np.where(has_payment, np.maximum(payment_age, 0.0), 0.0)
    result["refund_censor_bin"] = _event_bin(
        np.minimum(refund_follow_up, windows.refund_seconds),
        windows.refund_seconds,
        windows.hazard_intervals,
    )
    result["net_label"] = (
        purchase_observed & refund_mature & ~refund_observed
    ).astype(np.int8)
    result["net_mature"] = (purchase_mature & (~purchase_observed | refund_mature)).astype(
        np.int8
    )
    return result


def segment_boundaries(
    start: pd.Timestamp, end: pd.Timestamp, interval_seconds: int = 900
) -> list[pd.Timestamp]:
    if end <= start:
        raise ValueError("end must be after start")
    return list(pd.date_range(start=start, end=end, freq=f"{interval_seconds}s", inclusive="left"))


def assert_prediction_before_update(prediction_time: pd.Timestamp, update_time: pd.Timestamp) -> None:
    if prediction_time > update_time:
        raise ValueError("Prediction must precede the associated streaming update")
