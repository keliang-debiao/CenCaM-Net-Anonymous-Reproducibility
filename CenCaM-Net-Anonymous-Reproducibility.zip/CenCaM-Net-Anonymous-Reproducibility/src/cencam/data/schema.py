from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

import pandas as pd


@dataclass(frozen=True)
class DataContract:
    click_id: str = "click_id"
    user_id: str = "user_id"
    item_id: str = "item_id"
    click_time: str = "click_time"
    payment_time: str = "payment_time"
    refund_time: str = "refund_time"

    @property
    def required(self) -> tuple[str, ...]:
        return (
            self.click_id,
            self.user_id,
            self.item_id,
            self.click_time,
            self.payment_time,
            self.refund_time,
        )


def validate_frame(
    frame: pd.DataFrame,
    contract: DataContract = DataContract(),
    require_unique_clicks: bool = True,
) -> dict[str, int]:
    missing = sorted(set(contract.required) - set(frame.columns))
    if missing:
        raise ValueError(f"Missing required fields: {missing}")
    if require_unique_clicks and frame[contract.click_id].duplicated().any():
        raise ValueError("click_id values must be unique")
    for column in (contract.click_time, contract.payment_time, contract.refund_time):
        if not pd.api.types.is_datetime64_any_dtype(frame[column]):
            raise TypeError(f"{column} must be a datetime field")
    payment_before_click = int(
        (
            frame[contract.payment_time].notna()
            & (frame[contract.payment_time] < frame[contract.click_time])
        ).sum()
    )
    refund_before_payment = int(
        (
            frame[contract.refund_time].notna()
            & frame[contract.payment_time].notna()
            & (frame[contract.refund_time] < frame[contract.payment_time])
        ).sum()
    )
    if payment_before_click or refund_before_payment:
        raise ValueError(
            "Chronology audit failed: "
            f"payment_before_click={payment_before_click}, "
            f"refund_before_payment={refund_before_payment}"
        )
    return {
        "rows": int(len(frame)),
        "payment_before_click": payment_before_click,
        "refund_before_payment": refund_before_payment,
    }


def require_columns(frame: pd.DataFrame, columns: Iterable[str]) -> None:
    missing = sorted(set(columns) - set(frame.columns))
    if missing:
        raise ValueError(f"Missing fields: {missing}")

