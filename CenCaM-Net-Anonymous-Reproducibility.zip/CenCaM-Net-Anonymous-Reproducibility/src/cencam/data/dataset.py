from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np


class PreparedArrayStore:
    """Memory-mapped access to prepared arrays."""

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.arrays = np.load(self.path, mmap_mode="r", allow_pickle=False)
        lengths = {array.shape[0] for array in self.arrays.values()}
        if len(lengths) != 1:
            raise ValueError("All prepared arrays must share the first dimension")
        self.length = lengths.pop()

    def __len__(self) -> int:
        return self.length

    def __getitem__(self, index: int) -> dict[str, Any]:
        return {name: np.asarray(array[index]) for name, array in self.arrays.items()}


def torch_dataset(path: str | Path):
    import torch

    store = PreparedArrayStore(path)

    class _Dataset(torch.utils.data.Dataset):
        def __len__(self) -> int:
            return len(store)

        def __getitem__(self, index: int) -> dict[str, torch.Tensor]:
            row = store[index]
            return {name: torch.as_tensor(value) for name, value in row.items()}

    return _Dataset()

