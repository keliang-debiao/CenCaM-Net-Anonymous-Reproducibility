from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass
from typing import Any, Hashable, Iterable


@dataclass(frozen=True)
class HistoryEvent:
    timestamp: int
    event_id: Hashable
    payload: Any


class CausalHistoryBuilder:
    """Maintains bounded histories with a strict timestamp boundary."""

    def __init__(self, user_length: int = 128, item_length: int = 64) -> None:
        self.user_length = user_length
        self.item_length = item_length
        self._users: dict[Hashable, deque[HistoryEvent]] = defaultdict(
            lambda: deque(maxlen=user_length)
        )
        self._items: dict[Hashable, deque[HistoryEvent]] = defaultdict(
            lambda: deque(maxlen=item_length)
        )

    @staticmethod
    def _strictly_past(events: Iterable[HistoryEvent], target_time: int) -> list[HistoryEvent]:
        result = [event for event in events if event.timestamp < target_time]
        if any(event.timestamp >= target_time for event in result):
            raise AssertionError("History contains a non-past event")
        return result

    def query(self, user_id: Hashable, item_id: Hashable, target_time: int) -> dict[str, list]:
        return {
            "user_history": self._strictly_past(self._users[user_id], target_time),
            "item_history": self._strictly_past(self._items[item_id], target_time),
        }

    def append(
        self,
        user_id: Hashable,
        item_id: Hashable,
        timestamp: int,
        event_id: Hashable,
        payload: Any,
    ) -> None:
        event = HistoryEvent(timestamp=timestamp, event_id=event_id, payload=payload)
        if self._users[user_id] and timestamp < self._users[user_id][-1].timestamp:
            raise ValueError("User events must be appended chronologically")
        if self._items[item_id] and timestamp < self._items[item_id][-1].timestamp:
            raise ValueError("Item events must be appended chronologically")
        self._users[user_id].append(event)
        self._items[item_id].append(event)

    def query_then_append(
        self,
        user_id: Hashable,
        item_id: Hashable,
        timestamp: int,
        event_id: Hashable,
        payload: Any,
    ) -> dict[str, list]:
        histories = self.query(user_id, item_id, timestamp)
        self.append(user_id, item_id, timestamp, event_id, payload)
        return histories

