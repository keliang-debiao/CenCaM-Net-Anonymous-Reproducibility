from __future__ import annotations

import hashlib
from collections import defaultdict, deque
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from .schema import validate_frame


def stable_uint64(value: Any) -> np.uint64:
    digest = hashlib.blake2b(str(value).encode("utf-8"), digest_size=8).digest()
    return np.frombuffer(digest, dtype="<u8")[0]


def _vector(value: Any, width: int, dtype: Any) -> np.ndarray:
    array = np.asarray(value, dtype=dtype)
    if array.shape != (width,):
        raise ValueError(f"Feature vector has shape {array.shape}; expected {(width,)}")
    return array


def read_canonical_events(path: str | Path) -> pd.DataFrame:
    path = Path(path)
    if path.suffix.lower() == ".parquet":
        frame = pd.read_parquet(path)
    elif path.suffix.lower() in {".csv", ".csv.gz"} or path.name.endswith(".csv.gz"):
        frame = pd.read_csv(path)
    else:
        raise ValueError("Canonical input must be Parquet or CSV")
    for name in ("click_time", "payment_time", "refund_time"):
        frame[name] = pd.to_datetime(frame[name], utc=True, errors="coerce")
    validate_frame(frame)
    return frame.sort_values(["click_time", "click_id"], kind="stable").reset_index(drop=True)


def assign_day_index(frame: pd.DataFrame) -> pd.DataFrame:
    result = frame.copy()
    first_day = result["click_time"].dt.floor("D").min()
    result["day_index"] = (
        (result["click_time"].dt.floor("D") - first_day).dt.days + 1
    ).astype(np.int16)
    return result


def _left_padded(
    history: deque[tuple[pd.Timestamp, np.ndarray]],
    target_time: pd.Timestamp,
    length: int,
    width: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    values = np.zeros((length, width), dtype=np.float32)
    mask = np.zeros(length, dtype=np.bool_)
    buckets = np.zeros(length, dtype=np.int16)
    take = list(history)[-length:]
    if take:
        values[-len(take) :] = np.asarray([entry[1] for entry in take], dtype=np.float32)
        mask[-len(take) :] = True
        seconds = np.asarray(
            [max(0.0, (target_time - entry[0]).total_seconds()) for entry in take]
        )
        buckets[-len(take) :] = np.clip(np.floor(np.log2(1.0 + seconds / 60.0)), 0, 63)
    return values, mask, buckets


def prepare_arrays(
    frame: pd.DataFrame,
    dense_width: int,
    user_length: int,
    item_length: int,
) -> dict[str, np.ndarray]:
    required = {
        "dense_features",
        "purchase_observed",
        "purchase_mature",
        "refund_observed",
        "refund_mature",
        "purchase_event_bin",
        "refund_event_bin",
        "purchase_censor_bin",
        "refund_censor_bin",
        "net_label",
        "net_mature",
        "day_index",
    }
    missing = sorted(required - set(frame.columns))
    if missing:
        raise ValueError(f"Canonical preparation fields are absent: {missing}")

    user_history: dict[Any, deque[tuple[pd.Timestamp, np.ndarray]]] = defaultdict(
        lambda: deque(maxlen=user_length)
    )
    item_history: dict[Any, deque[tuple[pd.Timestamp, np.ndarray]]] = defaultdict(
        lambda: deque(maxlen=item_length)
    )
    rows: dict[str, list[Any]] = defaultdict(list)
    for record in frame.itertuples(index=False):
        dense = _vector(record.dense_features, dense_width, np.float32)
        user_values, user_mask, user_delay = _left_padded(
            user_history[record.user_id], record.click_time, user_length, dense_width
        )
        item_values, item_mask, item_delay = _left_padded(
            item_history[record.item_id], record.click_time, item_length, dense_width
        )
        rows["current_dense"].append(dense)
        rows["user_history_dense"].append(user_values)
        rows["item_history_dense"].append(item_values)
        rows["user_history_mask"].append(user_mask)
        rows["item_history_mask"].append(item_mask)
        rows["user_history_delay_bucket"].append(user_delay)
        rows["item_history_delay_bucket"].append(item_delay)
        for name in (
            "purchase_observed",
            "purchase_mature",
            "refund_observed",
            "refund_mature",
            "purchase_event_bin",
            "refund_event_bin",
            "purchase_censor_bin",
            "refund_censor_bin",
            "net_label",
            "net_mature",
            "day_index",
        ):
            rows[name].append(getattr(record, name))
        rows["click_id"].append(stable_uint64(record.click_id))
        user_history[record.user_id].append((record.click_time, dense))
        item_history[record.item_id].append((record.click_time, dense))
    return {name: np.asarray(values) for name, values in rows.items()}


def split_name(day: int) -> str:
    if 1 <= day <= 6:
        return "train"
    if day == 7:
        return "selection"
    if day == 8:
        return "calibration"
    if 9 <= day <= 14:
        return "replay"
    if 15 <= day <= 19:
        return "test"
    return "support"


def write_split_shards(
    arrays: dict[str, np.ndarray],
    destination: str | Path,
    shard_rows: int = 250_000,
) -> list[Path]:
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=True)
    days = arrays["day_index"]
    written: list[Path] = []
    for name in sorted({split_name(int(day)) for day in np.unique(days)}):
        indices = np.flatnonzero(np.array([split_name(int(day)) == name for day in days]))
        for shard, start in enumerate(range(0, len(indices), shard_rows)):
            selected = indices[start : start + shard_rows]
            path = destination / f"{name}_{shard:04d}.npz"
            np.savez_compressed(path, **{key: value[selected] for key, value in arrays.items()})
            written.append(path)
    return written
