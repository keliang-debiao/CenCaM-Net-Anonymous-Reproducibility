from __future__ import annotations

from collections.abc import Callable

import numpy as np


def moving_block_indices(
    length: int, block_length: int, rng: np.random.Generator
) -> np.ndarray:
    if length <= 0 or block_length <= 0:
        raise ValueError("length and block_length must be positive")
    block_length = min(block_length, length)
    starts = rng.integers(0, length - block_length + 1, size=int(np.ceil(length / block_length)))
    indices = np.concatenate([np.arange(start, start + block_length) for start in starts])
    return indices[:length]


def paired_moving_block_bootstrap(
    labels: np.ndarray,
    first: np.ndarray,
    second: np.ndarray,
    metric: Callable[[np.ndarray, np.ndarray], float],
    block_length: int,
    replicates: int = 10000,
    seed: int = 2026,
) -> dict[str, float]:
    labels = np.asarray(labels)
    first = np.asarray(first)
    second = np.asarray(second)
    if not (len(labels) == len(first) == len(second)):
        raise ValueError("Paired arrays must have the same length")
    rng = np.random.default_rng(seed)
    differences = np.empty(replicates, dtype=np.float64)
    for index in range(replicates):
        draw = moving_block_indices(len(labels), block_length, rng)
        differences[index] = metric(labels[draw], first[draw]) - metric(labels[draw], second[draw])
    observed = metric(labels, first) - metric(labels, second)
    lower, upper = np.quantile(differences, [0.025, 0.975])
    non_improving = int(np.sum(differences <= 0.0))
    p_value = 2.0 * (min(non_improving, replicates - non_improving) + 1) / (replicates + 1)
    return {
        "difference": float(observed),
        "ci_lower": float(lower),
        "ci_upper": float(upper),
        "non_improving": non_improving,
        "p_value": float(min(1.0, p_value)),
    }


def holm_adjust(p_values: list[float]) -> list[float]:
    values = np.asarray(p_values, dtype=np.float64)
    order = np.argsort(values)
    adjusted = np.empty_like(values)
    running = 0.0
    count = len(values)
    for rank, index in enumerate(order):
        candidate = min(1.0, (count - rank) * values[index])
        running = max(running, candidate)
        adjusted[index] = running
    return adjusted.tolist()

