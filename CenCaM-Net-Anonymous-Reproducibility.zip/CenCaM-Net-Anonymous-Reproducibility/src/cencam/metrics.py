from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from sklearn.metrics import average_precision_score, log_loss, roc_auc_score


def expected_calibration_error(
    y_true: np.ndarray, y_prob: np.ndarray, bins: int = 15
) -> float:
    y_true = np.asarray(y_true, dtype=np.float64)
    y_prob = np.asarray(y_prob, dtype=np.float64)
    if len(y_true) == 0:
        return float("nan")
    quantiles = np.unique(np.quantile(y_prob, np.linspace(0.0, 1.0, bins + 1)))
    if len(quantiles) < 2:
        return abs(float(y_true.mean() - y_prob.mean()))
    membership = np.digitize(y_prob, quantiles[1:-1], right=True)
    error = 0.0
    for index in range(len(quantiles) - 1):
        mask = membership == index
        if not np.any(mask):
            continue
        error += mask.mean() * abs(y_true[mask].mean() - y_prob[mask].mean())
    return float(error)


def probability_over_prediction(y_true: np.ndarray, y_prob: np.ndarray) -> float:
    prediction_rate = float(np.mean(y_prob))
    return float(np.mean(y_true) / prediction_rate) if prediction_rate > 0 else float("inf")


def binary_metrics(
    y_true: np.ndarray, y_prob: np.ndarray, bins: int = 15
) -> dict[str, float]:
    y_true = np.asarray(y_true, dtype=np.int64)
    y_prob = np.clip(np.asarray(y_prob, dtype=np.float64), 1e-6, 1 - 1e-6)
    return {
        "auc": float(roc_auc_score(y_true, y_prob)),
        "pr_auc": float(average_precision_score(y_true, y_prob)),
        "nll": float(log_loss(y_true, y_prob, labels=[0, 1])),
        "brier": float(np.mean((y_prob - y_true) ** 2)),
        "ece": expected_calibration_error(y_true, y_prob, bins),
        "pcoc": probability_over_prediction(y_true, y_prob),
    }


def group_auc(
    y_true: np.ndarray, y_prob: np.ndarray, group: np.ndarray
) -> float:
    y_true = np.asarray(y_true)
    y_prob = np.asarray(y_prob)
    group = np.asarray(group)
    weighted = 0.0
    total = 0
    for value in np.unique(group):
        mask = group == value
        labels = y_true[mask]
        if len(np.unique(labels)) < 2:
            continue
        count = int(mask.sum())
        weighted += count * roc_auc_score(labels, y_prob[mask])
        total += count
    return float(weighted / total) if total else float("nan")

