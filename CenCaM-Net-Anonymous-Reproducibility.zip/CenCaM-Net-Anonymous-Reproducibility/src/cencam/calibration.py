from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.optimize import minimize
from scipy.special import expit
from sklearn.isotonic import IsotonicRegression


def _clip(probabilities: np.ndarray) -> np.ndarray:
    return np.clip(np.asarray(probabilities, dtype=np.float64), 1e-6, 1 - 1e-6)


@dataclass
class TemperatureCalibrator:
    temperature: float = 1.0

    def fit(self, probabilities: np.ndarray, labels: np.ndarray) -> "TemperatureCalibrator":
        probabilities = _clip(probabilities)
        labels = np.asarray(labels, dtype=np.float64)
        logits = np.log(probabilities / (1.0 - probabilities))

        def objective(raw: np.ndarray) -> float:
            temperature = np.exp(raw[0])
            score = logits / temperature
            return float(np.mean(np.logaddexp(0.0, score) - labels * score))

        result = minimize(objective, np.array([0.0]), method="BFGS")
        self.temperature = float(np.exp(result.x[0]))
        return self

    def predict(self, probabilities: np.ndarray) -> np.ndarray:
        probabilities = _clip(probabilities)
        logits = np.log(probabilities / (1 - probabilities))
        return _clip(expit(logits / self.temperature))


@dataclass
class BetaCalibrator:
    a: float = 1.0
    b: float = 1.0
    c: float = 0.0

    def fit(self, probabilities: np.ndarray, labels: np.ndarray) -> "BetaCalibrator":
        probabilities = _clip(probabilities)
        labels = np.asarray(labels, dtype=np.float64)
        log_p = np.log(probabilities)
        log_one_minus = np.log1p(-probabilities)

        def objective(parameters: np.ndarray) -> float:
            score = parameters[0] * log_p - parameters[1] * log_one_minus + parameters[2]
            return float(np.mean(np.logaddexp(0.0, score) - labels * score))

        result = minimize(objective, np.array([1.0, 1.0, 0.0]), method="BFGS")
        self.a, self.b, self.c = map(float, result.x)
        return self

    def predict(self, probabilities: np.ndarray) -> np.ndarray:
        probabilities = _clip(probabilities)
        score = self.a * np.log(probabilities) - self.b * np.log1p(-probabilities) + self.c
        return _clip(expit(score))


class IsotonicCalibrator:
    def __init__(self) -> None:
        self.model = IsotonicRegression(out_of_bounds="clip")

    def fit(self, probabilities: np.ndarray, labels: np.ndarray) -> "IsotonicCalibrator":
        self.model.fit(np.asarray(probabilities), np.asarray(labels))
        return self

    def predict(self, probabilities: np.ndarray) -> np.ndarray:
        return np.asarray(self.model.predict(np.asarray(probabilities)), dtype=np.float64)


def make_calibrator(name: str):
    normalized = name.lower().replace("-", "_")
    if normalized == "beta":
        return BetaCalibrator()
    if normalized == "temperature":
        return TemperatureCalibrator()
    if normalized == "isotonic":
        return IsotonicCalibrator()
    raise ValueError(f"Unknown calibration method: {name}")
