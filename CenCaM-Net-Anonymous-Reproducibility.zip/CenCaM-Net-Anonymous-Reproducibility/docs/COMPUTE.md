# Compute Profile

The reported timing environment used one NVIDIA A100 80 GB, PyTorch 2.6, CUDA 12.4, and BF16 with batch size 8192.

The selected model has four dual-history encoder layers, model width 128, four MIMO groups, 16 complex states per group, four shared experts, two conversion-private experts, two refund-private experts, and 12 hazard intervals.

The measured mean end-to-end 15-minute update time was 73 seconds. History lookup and materialization accounted for 41.8 seconds. Model-only throughput excludes source-data I/O, history construction, delayed-event delivery, and checkpoint writing.

For smaller accelerators, reduce `optimization.batch_size`, enable gradient accumulation, and keep all temporal split and label-maturity rules unchanged.

