# Anonymous Review Checklist

- Repository title, package metadata, and documentation contain no author names or affiliations.
- Raw data, credentials, private links, local machine paths, and trained checkpoints are excluded.
- Public data are referenced through their official repositories or project pages.
- The source package contains no manuscript response letter or reviewer identity.
- Test-day labels are blocked from model selection, early stopping, calibration fitting, and hyperparameter search.
- The five fixed seeds and every resolved configuration are recorded.
- Reference records are separated from newly produced outputs and are explicitly identified as manuscript-aligned parser and aggregation fixtures.
- `python scripts/verify_repository.py --strict` must pass before upload.

