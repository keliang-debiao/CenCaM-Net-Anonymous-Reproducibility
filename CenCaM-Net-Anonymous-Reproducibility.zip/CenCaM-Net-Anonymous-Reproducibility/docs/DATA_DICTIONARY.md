# Data Dictionary

## Primary event fields

| Field | Type | Meaning |
|---|---|---|
| `click_id` | string or integer | Stable click identifier |
| `user_id` | string or integer | Anonymous user identifier |
| `item_id` | string or integer | Anonymous item identifier |
| `click_time` | timestamp | Prediction-time boundary |
| `payment_time` | timestamp or null | Purchase event time |
| `refund_time` | timestamp or null | Refund event time |
| `dense_features` | float vector | Click-time observable numeric fields |
| `categorical_features` | integer vector | Train-vocabulary categorical fields |

The preparation command consumes one chronologically sortable Parquet or CSV table with these canonical names. Dataset-specific field mapping is intentionally kept outside the model code because upstream releases can change their storage layout while preserving the event semantics. `dense_features` must have the width declared by `model.dense_input_dim`; categorical identifiers must be mapped with a training-only vocabulary before preparation.

## Derived targets

- `purchase_observed`: purchase delivered by the current observation boundary.
- `purchase_mature`: purchase attribution window has closed.
- `refund_observed`: refund delivered by the current observation boundary.
- `refund_mature`: refund attribution window has closed for a purchased item.
- `net_label`: one only for a purchase without an attributed refund after both stages mature.
- `purchase_event_bin` and `refund_event_bin`: discrete event intervals for hazard likelihoods.

## Sequence fields

- user history length: 128;
- item history length: 64;
- histories are left padded;
- masks equal one at valid strictly past positions;
- relative-delay buckets are computed from target time minus history-event time.

The prepared shard contract additionally contains `purchase_censor_bin`, `refund_censor_bin`, `purchase_mature`, `refund_mature`, `net_mature`, `day_index`, a stable unsigned click key, and the two relative-delay-bucket tensors.
