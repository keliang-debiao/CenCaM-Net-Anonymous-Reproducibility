# Runbook

## 1. Prepare the environment

Create the pinned environment, install the package, and run repository verification.

## 2. Register public data

Follow `data/README.md`. Preserve upstream files, record SHA-256 values, and keep all raw files outside version control.

## 3. Build chronological artifacts

Map each upstream release to the canonical fields in `docs/DATA_DICTIONARY.md`. Run `scripts/prepare_data.py` with the target configuration and `--input` path. Inspect the chronology audit, label-maturity counts, registered hashes, and split manifest before training.

## 4. Run shadow selection

Run the 24 Sobol configurations through D6, save D7-D8 predictions without gradient updates, and select only with matured D7 metrics.

## 5. Replay and evaluate

Reconstruct the selected D1-D6 checkpoint, advance histories over D7-D8 without gradients, replay D9-D14 with observable feedback, fit the D8 calibrator, and evaluate D15-D19.

## 6. Aggregate seeds

Run seeds 2026-2030. Build the ensemble from probability averages, then compute window metrics, paired intervals, block-length sensitivity, and adjusted significance values.

## 7. Run controlled studies

Execute the ablation matrix, frozen-prediction delay perturbation, MAC transfer, and ASOS transfer. Each run must write a resolved configuration and manifest.

## 8. Rebuild tables

Use `scripts/build_reference_records.py` only to restore the immutable manuscript-aligned records. Use newly produced outputs for empirical verification.
