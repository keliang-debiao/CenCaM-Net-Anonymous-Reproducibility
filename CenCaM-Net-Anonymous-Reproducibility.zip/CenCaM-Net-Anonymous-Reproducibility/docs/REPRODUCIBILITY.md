# Reproducibility Protocol

## Determinism

The run seed controls Python, NumPy, PyTorch CPU, and PyTorch CUDA generators. Deterministic algorithms are enabled when the selected operation supports them. The environment report records CUDA, cuDNN, device, precision, and package versions.

## Chronology

Rows are sorted by original click time. Histories include only events with timestamps strictly earlier than the target click. Prediction is completed before any update using feedback delivered in the same 15-minute segment.

## Label maturity

Purchase and refund outcomes have separate attribution windows. An unobserved event is treated as right-censored until its attribution window closes. The purchase hazard uses all clicks. The refund hazard is normalized over converted observations only.

## Selection and calibration

Twenty-four Sobol configurations are fixed before D7. Matured D7 PR-AUC selects the configuration, with D7 NLL and parameter count as tie breakers. D8 predictions are saved without gradients and are used to fit calibration only after D8 labels mature. The calibrator is frozen before D15.

## Held-out evaluation

D15-D19 are five rolling-origin test windows. Predictions are made before streaming updates. Final labels mature by D21-D25. Reported uncertainty uses paired moving-block resampling of seed-ensemble predictions.

## External-stage transfer

MAC evaluates conversion-stage transfer. ASOS GraphReturns evaluates return-stage compatibility. Neither result is interpreted as complete cross-platform NetCVR validation.

