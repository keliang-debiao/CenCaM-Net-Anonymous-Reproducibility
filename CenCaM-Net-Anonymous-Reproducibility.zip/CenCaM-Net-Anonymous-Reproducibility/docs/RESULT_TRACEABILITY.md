# Result Traceability

| Manuscript evidence | Configuration or record |
|---|---|
| Main five-window CASCADE metrics | `configs/cascade.yaml`, `records/cascade/main_summary.csv` |
| Leakage and update-protocol diagnostics | `records/cascade/protocol_diagnostics.csv` |
| Baseline comparison with seed dispersion | `records/cascade/baseline_summary.csv` |
| Window-level D15-D19 values | `records/cascade/window_metrics.csv` |
| Objective-family selection | `records/cascade/objective_selection.csv` |
| Hazard and label handling | `records/cascade/hazard_diagnostics.csv` |
| Component ablations | `configs/ablation_matrix.yaml`, `records/cascade/ablation_summary.csv` |
| Calibration comparison | `records/cascade/calibration_summary.csv` |
| Delay perturbation | `configs/delay_shift_matrix.yaml`, `records/cascade/delay_shift_summary.csv` |
| Feature masking and cold-start checks | `records/cascade/robustness_summary.csv` |
| OOV and representation-drift analysis | `records/cascade/drift_summary.csv` |
| Purchase/refund-window sensitivity | `records/cascade/window_sensitivity.csv` |
| Statistical comparisons | `records/cascade/statistical_summary.csv` |
| Moving-block length sensitivity | `records/cascade/block_sensitivity.csv` |
| Computational profile | `records/cascade/efficiency_summary.csv` |
| Routing and history interpretation | `records/cascade/routing_summary.csv` |
| MAC transfer and auxiliary labels | `configs/mac_transfer.yaml`, `records/external/mac_summary.csv`, `records/external/mac_auxiliary.csv` |
| ASOS transfer and customer subgroups | `configs/asos_transfer.yaml`, `records/external/asos_summary.csv`, `records/external/asos_subgroups.csv` |

Every reference record contains `record_origin=manuscript_aligned_reference`. New empirical outputs must contain `record_origin=executed_run` and the corresponding checkpoint, data-manifest, and environment hashes.
